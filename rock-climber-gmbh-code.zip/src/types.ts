export type Page = 'home' | 'about' | 'shop' | 'contact' | 'terms' | 'privacy';

export type Theme = 'dark' | 'light';

export type FrameSize = 'S' | 'M' | 'L' | 'XL';

export interface Product {
  id: string;
  name: string;
  sku: string;
  price: number;
  weight: number; // in grams
  category: 'drivetrain' | 'wheels' | 'cockpit' | 'frame';
  badge?: string;
  spec: string;
  image: string;
  description: string;
  inStock: boolean;
  popularity: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  size?: FrameSize;
  selectedSize?: FrameSize;
}

export interface Hotspot {
  id: number;
  title: string;
  category: string;
  code: string;
  description: string;
  specs: { label: string; value: string }[];
  position: {
    top: string;
    left: string;
  };
}

export interface TestRideSubmission {
  protocol: 'ride' | 'dealer' | 'inquiry';
  fullName: string;
  email: string;
  phone: string;
  location: string;
  frameSize: FrameSize;
  date: string;
  timeSlot: string;
  companyName?: string;
  vatId?: string;
  plannedVolume?: string;
  dealerCity?: string;
  technicalNotes: string;
  agreedToLiability: boolean;
}

export interface GdprSubmission {
  fullName: string;
  email: string;
  requestType: string;
  serialNumber?: string;
  notes: string;
  verified: boolean;
}
