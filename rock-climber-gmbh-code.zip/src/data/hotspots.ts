import { Hotspot } from '../types';

export const HOTSPOTS: Hotspot[] = [
  {
    id: 1,
    title: 'RST Blaze 100mm Front Fork',
    category: 'Front Suspension',
    code: 'RST-BLZ-100',
    description: 'Hydro lockout dampening system with variable coil preload adjustment designed for root-heavy alpine descents and high-stress rock gardens.',
    specs: [
      { label: 'TRAVEL', value: '100 mm' },
      { label: 'STANCHIONS', value: '32 mm Steel' },
      { label: 'LOCKOUT', value: 'Crown Mechanical' },
      { label: 'AXLE', value: '9x100 mm QR' }
    ],
    position: {
      top: '44%',
      left: '74%'
    }
  },
  {
    id: 2,
    title: 'Shimano 1x11 Derailleur & Clutch',
    category: 'Drivetrain',
    code: 'SHIM-1X11-RD',
    description: 'Hyperglide ultra-crisp shift ratio with Shadow RD+ clutch stabilization to eradicate chain slap across rough terrain and high cadence pedaling.',
    specs: [
      { label: 'CASSETTE', value: '11-46T Hyperglide' },
      { label: 'CHAINRING', value: '32T Narrow-Wide' },
      { label: 'CLUTCH', value: 'Shadow RD+ Active' },
      { label: 'CRANKSET', value: 'Forged Alloy 175mm' }
    ],
    position: {
      top: '68%',
      left: '26%'
    }
  },
  {
    id: 3,
    title: '29" White-Sidewall Knobby Tires & Hub',
    category: 'Wheelset',
    code: 'RC-WHL-29WS',
    description: 'Signature alpine white sidewall rubber compound wrapped around tubeless-ready double-wall alloy rims with sealed cartridge bearings.',
    specs: [
      { label: 'DIAMETER', value: '29 Inch' },
      { label: 'TIRE WIDTH', value: '2.35" All-Terrain' },
      { label: 'BEAD', value: 'Kevlar Folding' },
      { label: 'HUB', value: 'RC Direct 32H' }
    ],
    position: {
      top: '74%',
      left: '80%'
    }
  },
  {
    id: 4,
    title: 'Alloy Flat Bar Cockpit & Shimano Levers',
    category: 'Cockpit Architecture',
    code: 'RC-CKP-FLAT',
    description: 'Aggressive 9-degree backsweep aluminum flat bar combined with micro-knurled silicone lock-on grips and Shimano mineral-oil brake levers.',
    specs: [
      { label: 'BAR WIDTH', value: '760 mm' },
      { label: 'CLAMP', value: '31.8 mm' },
      { label: 'BACKSWEEP', value: '9 Degrees' },
      { label: 'BRAKES', value: 'Hydraulic 2-Piston' }
    ],
    position: {
      top: '28%',
      left: '64%'
    }
  },
  {
    id: 5,
    title: 'Hydroformed 6061-T6 Monocoque Frame',
    category: 'Chassis Backbone',
    code: 'RC-FRM-101HT',
    description: 'Multi-butted aerospace 6061 aluminum tubing with smooth double-pass TIG welds, internal cable routing, and Stealth Matte Obsidian finish.',
    specs: [
      { label: 'ALLOY', value: 'AL 6061-T6 + SC' },
      { label: 'ROUTING', value: 'Full Internal' },
      { label: 'SPACING', value: 'Boost 148x12mm' },
      { label: 'WARRANTY', value: '5-Year Frame' }
    ],
    position: {
      top: '38%',
      left: '46%'
    }
  }
];
