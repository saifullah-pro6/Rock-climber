import React, { useState, useEffect } from 'react';
import { Page, Theme, FrameSize, CartItem, Product } from './types';
import { FLAGSHIP_BIKE } from './data/products';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { OrderModal } from './components/OrderModal';
import { SizeGuideModal } from './components/SizeGuideModal';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { PartsShopPage } from './pages/PartsShopPage';
import { ContactPage } from './pages/ContactPage';
import { TermsPage } from './pages/TermsPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { ShoppingBag, X } from 'lucide-react';

export default function App() {
  // Theme state: defaults to 'dark' for stealth Bavarian engineering look
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('rc_theme') as Theme;
      if (saved === 'light' || saved === 'dark') return saved;
    }
    return 'dark';
  });

  // Current page state
  const [currentPage, setCurrentPage] = useState<Page>('home');

  // Selected frame size for the RC 101
  const [selectedSize, setSelectedSize] = useState<FrameSize>('M');

  // Modals & Drawers state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);

  // Cart state
  const [cart, setCart] = useState<CartItem[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('rc_cart');
        if (saved) return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return [
      {
        product: FLAGSHIP_BIKE,
        quantity: 1,
        size: 'M'
      }
    ];
  });

  // Toast notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync theme with DOM documentElement and localStorage
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
    }
    localStorage.setItem('rc_theme', theme);
  }, [theme]);

  // Sync cart with localStorage
  useEffect(() => {
    localStorage.setItem('rc_cart', JSON.stringify(cart));
  }, [cart]);

  // Scroll to top on navigation
  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage((current) => (current === message ? null : current));
    }, 3500);
  };

  const handleAddToCart = (product: Product, size?: FrameSize) => {
    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex(
        (item) => item.product.sku === product.sku && item.size === size
      );

      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += 1;
        return updated;
      } else {
        return [...prevCart, { product, quantity: 1, size }];
      }
    });

    showToast(`Added ${product.name} to shopping bag.`);
  };

  const handleUpdateQuantity = (sku: string, quantity: number) => {
    setCart((prevCart) => {
      if (quantity <= 0) {
        return prevCart.filter((item) => item.product.sku !== sku);
      }
      return prevCart.map((item) => {
        if (item.product.sku === sku) {
          return { ...item, quantity };
        }
        return item;
      });
    });
  };

  const handleRemoveFromCart = (sku: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.sku !== sku));
  };

  const handleOrderSuccess = () => {
    setCart([]);
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[var(--bg-main)] text-[var(--text-primary)] transition-colors duration-300 selection:bg-orange-500 selection:text-white">
      {/* Sticky Glassmorphism Header */}
      <Header
        currentPage={currentPage}
        onNavigate={handleNavigate}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenOrderModal={() => setIsOrderModalOpen(true)}
      />

      {/* Main Page Routing View */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            selectedSize={selectedSize}
            onSelectSize={setSelectedSize}
            onOpenOrderModal={() => setIsOrderModalOpen(true)}
            onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
            onNavigateToShop={() => handleNavigate('shop')}
            onNavigateToContact={() => handleNavigate('contact')}
          />
        )}

        {currentPage === 'about' && (
          <AboutPage
            onOpenOrderModal={() => setIsOrderModalOpen(true)}
            onNavigateToContact={() => handleNavigate('contact')}
          />
        )}

        {currentPage === 'shop' && (
          <PartsShopPage
            onAddToCart={handleAddToCart}
            onOpenCart={() => setIsCartOpen(true)}
            cartCount={totalCartCount}
            onNavigateToContact={() => handleNavigate('contact')}
          />
        )}

        {currentPage === 'contact' && (
          <ContactPage
            onOpenOrderModal={() => setIsOrderModalOpen(true)}
            selectedSize={selectedSize}
            onSelectSize={setSelectedSize}
          />
        )}

        {currentPage === 'terms' && <TermsPage />}

        {currentPage === 'privacy' && <PrivacyPage />}
      </main>

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsOrderModalOpen(true);
        }}
        onNavigateToShop={() => {
          setIsCartOpen(false);
          handleNavigate('shop');
        }}
      />

      {/* Size Guide Modal */}
      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
        selectedSize={selectedSize}
        onSelectSize={(size) => {
          setSelectedSize(size);
          setIsSizeGuideOpen(false);
        }}
      />

      {/* Complete Order & Size Configuration Modal */}
      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        selectedSize={selectedSize}
        onSelectSize={setSelectedSize}
        cart={cart}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Notification Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-slide-up flex items-center gap-3 px-5 py-3.5 rounded-xl bg-[var(--bg-surface-elevated)] border border-orange-500/40 text-[var(--text-primary)] shadow-2xl shadow-orange-500/10">
          <div className="w-7 h-7 rounded-lg bg-orange-500/20 text-orange-500 flex items-center justify-center shrink-0">
            <ShoppingBag className="w-4 h-4" />
          </div>
          <p className="text-xs sm:text-sm font-medium">{toastMessage}</p>
          <button
            onClick={() => setToastMessage(null)}
            className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] ml-2 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 4-Column Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenOrderModal={() => setIsOrderModalOpen(true)}
      />
    </div>
  );
}
