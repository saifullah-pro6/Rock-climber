import React from 'react';
import {
  Shield,
  Lock,
  UserCheck,
  Server,
  FileCheck,
  EyeOff,
  Mail,
  CheckCircle2
} from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[var(--bg-main)] text-[var(--text-primary)] transition-colors duration-300">
      {/* Header */}
      <section className="relative pt-32 pb-16 border-b border-[var(--border-color)] overflow-hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-orange-500/30 bg-orange-500/10 text-orange-500 text-xs font-mono font-medium tracking-wider mb-4">
            <Lock className="w-3.5 h-3.5" />
            EU GENERAL DATA PROTECTION REGULATION (GDPR / DSGVO)
          </div>
          <h1 className="text-4xl md:text-5xl font-black uppercase tracking-tight text-[var(--text-primary)] mb-4">
            Privacy Policy <br />
            <span className="text-orange-500 font-extrabold">& Data Protection</span>
          </h1>
          <p className="text-sm sm:text-base text-[var(--text-secondary)]">
            We adhere rigorously to the European Union GDPR (Datenschutz-Grundverordnung) and the German Federal Data Protection Act (BDSG).
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          {/* Privacy Badges */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-color)]">
              <EyeOff className="w-6 h-6 text-orange-500 mb-3" />
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-primary)]">
                Zero Third-Party Trackers
              </h3>
              <p className="text-xs text-[var(--text-secondary)] mt-1">
                We do not sell data or embed predatory advertising behavioral trackers.
              </p>
            </div>
            <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-color)]">
              <Server className="w-6 h-6 text-orange-500 mb-3" />
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-primary)]">
                Hosted in Germany (EU)
              </h3>
              <p className="text-xs text-[var(--text-secondary)] mt-1">
                All order processing and customer databases operate in ISO 27001-certified German server facilities.
              </p>
            </div>
            <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-color)]">
              <UserCheck className="w-6 h-6 text-orange-500 mb-3" />
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-primary)]">
                Full User Rights
              </h3>
              <p className="text-xs text-[var(--text-secondary)] mt-1">
                Instant access, rectification, portability, and deletion requests handled within 48 hours.
              </p>
            </div>
          </div>

          {/* Section 1 */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[var(--text-primary)] flex items-center gap-2">
              <span className="text-orange-500 font-mono text-sm">1.</span>
              Name and Address of the Data Controller
            </h2>
            <div className="text-sm text-[var(--text-secondary)] space-y-3 leading-relaxed">
              <p>
                The Data Controller within the meaning of Article 4(7) GDPR is:
              </p>
              <div className="p-4 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-color)] font-mono text-xs text-[var(--text-primary)] space-y-1">
                <p className="font-bold">Rock Climber GmbH</p>
                <p>Data Protection Officer: Dipl.-Inf. Markus Eder</p>
                <p>Leopoldstraße 142, 80804 Munich, Bavaria, Germany</p>
                <p>Email: privacy@rockclimber.de</p>
                <p>Hotline: +49 (0) 89 4520 8910</p>
              </div>
            </div>
          </div>

          {/* Section 2 */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[var(--text-primary)] flex items-center gap-2">
              <span className="text-orange-500 font-mono text-sm">2.</span>
              Data Collection for Order Processing & Logistics
            </h2>
            <div className="text-sm text-[var(--text-secondary)] space-y-3 leading-relaxed">
              <p>
                When ordering the RC 101 or genuine components, we process personal contact data (Name, Shipping Address, Billing Address, Email, Phone) on the legal basis of Art. 6(1)(b) GDPR (performance of a contract).
              </p>
              <p>
                For courier freight transport, your delivery details and phone contact are transmitted strictly to our authorized German logistics partner (DHL Freight / Deutsche Post AG) solely to coordinate curbside pallet delivery.
              </p>
            </div>
          </div>

          {/* Section 3 */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[var(--text-primary)] flex items-center gap-2">
              <span className="text-orange-500 font-mono text-sm">3.</span>
              Your Rights Under GDPR (Art. 15–21)
            </h2>
            <div className="text-sm text-[var(--text-secondary)] space-y-2 leading-relaxed">
              <p>As a data subject, you hold comprehensive rights:</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-color)] text-xs">
                  <strong className="text-[var(--text-primary)] block mb-1">Right of Access (Art. 15)</strong>
                  Receive a complete export of all data stored concerning your person.
                </div>
                <div className="p-3 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-color)] text-xs">
                  <strong className="text-[var(--text-primary)] block mb-1">Right to Rectification (Art. 16)</strong>
                  Correct inaccurate shipping details or billing designations.
                </div>
                <div className="p-3 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-color)] text-xs">
                  <strong className="text-[var(--text-primary)] block mb-1">Right to Erasure (Art. 17)</strong>
                  Request permanent deletion subject to statutory fiscal retention laws.
                </div>
                <div className="p-3 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-color)] text-xs">
                  <strong className="text-[var(--text-primary)] block mb-1">Right to Data Portability (Art. 20)</strong>
                  Receive machine-readable structured JSON exports of your order histories.
                </div>
              </div>
            </div>
          </div>

          {/* Section 4 */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[var(--text-primary)] flex items-center gap-2">
              <span className="text-orange-500 font-mono text-sm">4.</span>
              Local Storage & Session Cookies
            </h2>
            <div className="text-sm text-[var(--text-secondary)] space-y-3 leading-relaxed">
              <p>
                Our web application uses essential browser storage strictly to remember your active theme preference (Dark or Light Mode) and your shopping bag contents. No profiling cookies or cross-site tracking tags are utilized.
              </p>
            </div>
          </div>

        </div>
      </section>
    </div>
  );
};
