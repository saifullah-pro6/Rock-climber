import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  MapPin,
  Quote,
  ShieldCheck,
  X,
  Target,
  Wrench,
  Layers,
  ArrowRight
} from 'lucide-react';

interface AboutPageProps {
  onOpenOrderModal: () => void;
  onNavigateToContact: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({
  onOpenOrderModal,
  onNavigateToContact
}) => {
  const [tourModalOpen, setTourModalOpen] = useState(false);
  const [tourSubmitted, setTourSubmitted] = useState(false);
  const [tourForm, setTourForm] = useState({
    name: '',
    email: '',
    date: '',
    riderNote: ''
  });

  const handleTourSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTourSubmitted(true);
    setTimeout(() => {
      setTourSubmitted(false);
      setTourModalOpen(false);
      setTourForm({ name: '', email: '', date: '', riderNote: '' });
    }, 2500);
  };

  return (
    <div className="flex flex-col w-full">
      {/* Hero Section */}
      <section className="relative w-full overflow-hidden bg-[#0F1115] pt-12 pb-20 px-4 sm:px-6 lg:px-12">
        <div className="absolute -top-32 right-10 w-96 h-96 rounded-full bg-[#FF5500]/10 blur-[130px] pointer-events-none" />
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
            <div className="inline-flex items-center gap-3 rounded-full bg-[#16191F] px-4 py-1.5 border border-[#2A2E35]">
              <span className="inline-block h-2 w-2 rounded-full bg-[#FF5500] animate-ping" />
              <span className="font-tech text-xs text-white uppercase font-bold">
                ISO 9001 / DIN 79100 COMPLIANT
              </span>
              <span className="text-slate-600">/</span>
              <span className="font-tech text-xs text-slate-400">
                MUNICH HQ: 48.1351° N, 11.5820° E
              </span>
            </div>
            <div className="font-tech text-xs text-slate-400">
              BATCH STATUS: <span className="text-[#FF5500] font-bold">RC-101 SERIES 04 ACTIVE</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6">
              <span className="font-tech text-xs text-[#FF5500] uppercase tracking-widest font-semibold block">
                // METALLURGY • AEROSPACE ALIGNMENT • GERMANY
              </span>
              <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl text-[#F4F5F7] uppercase tracking-tight font-extrabold leading-[1.1]">
                Precision Engineering. Born in Bavaria, Built for the Extreme.
              </h1>
              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
                At Rock Climber GmbH, we reject the cycle of seasonal gimmicks. Founded in 2020 by downhill cup racers and ex-aerospace stress analysts, we pour 100% of our computational fluid dynamics, metallurgical testing, and trail validation into one uncompromising chassis: <span className="text-white font-bold">The RC 101</span>.
              </p>

              <div className="pt-2 flex flex-wrap gap-4">
                <button
                  type="button"
                  onClick={() => setTourModalOpen(true)}
                  className="px-8 py-3.5 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider shadow-[0_10px_28px_rgba(255,85,0,0.35)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Book Factory Tour &amp; Ride</span>
                </button>
                <a
                  href="#heritage"
                  className="px-7 py-3.5 rounded-full border border-[#2A2E35] bg-[#16191F] text-slate-200 hover:text-white hover:border-[#FF5500] font-display text-xs font-bold uppercase tracking-wider transition-all"
                >
                  Explore Munich Lineage
                </a>
              </div>

              {/* Quick Facts Strip */}
              <div className="grid grid-cols-3 gap-3 sm:gap-4 pt-4">
                <div className="p-4 rounded-xl bg-[#16191F] border border-[#2A2E35]">
                  <div className="font-tech text-[10px] sm:text-xs text-slate-400">FRAME RIGIDITY</div>
                  <div className="font-display text-xl sm:text-2xl text-white font-bold mt-1">
                    142 <span className="text-xs font-tech text-[#FF5500]">N·m/°</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">Torsional Headtube</div>
                </div>
                <div className="p-4 rounded-xl bg-[#16191F] border border-[#2A2E35]">
                  <div className="font-tech text-[10px] sm:text-xs text-slate-400">TOLERANCE</div>
                  <div className="font-display text-xl sm:text-2xl text-white font-bold mt-1">
                    ±0.02 <span className="text-xs font-tech text-[#FF5500]">mm</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">CNC Pivot Sleeves</div>
                </div>
                <div className="p-4 rounded-xl bg-[#16191F] border border-[#2A2E35]">
                  <div className="font-tech text-[10px] sm:text-xs text-slate-400">TESTING MILES</div>
                  <div className="font-display text-xl sm:text-2xl text-white font-bold mt-1">
                    82.4k <span className="text-xs font-tech text-[#FF5500]">KM</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">Alpine Singletracks</div>
                </div>
              </div>
            </div>

            {/* Visual Chassis Blueprint Preview */}
            <div className="lg:col-span-5 relative">
              <div className="rounded-2xl bg-[#16191F] border border-[#2A2E35] p-5 shadow-2xl space-y-4">
                <div className="relative rounded-xl overflow-hidden bg-[#0C0E12] h-72 flex items-center justify-center">
                  <img
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuCe3-EeIBGGdkLFD0Q_vU_40AlKtOKFGxL7ALnNyqDDOe3101zLnyu4SIoL6ZwCULlEwXeXhh-jcBRkjmXDqp8IfGZvJdBjUHaozjpYn0JST89ldCN-HVNkVeMIY7d9SjGQk__LvQUmqthtYbwYvT19AARJ2GOZQLNiMTcLLKACcPZFqFfl_jxApwUvGml-qpj9KJ-2BEB81UZC2yXDxh6zKWkhTRSJV1SPQpSWJPMHrr8zp4pKNzrJ0g"
                    alt="RC 101 Chassis Blueprint"
                    className="w-full h-full object-contain p-2 hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute bottom-2 left-2 px-2.5 py-1 rounded bg-[#0F1115]/90 border border-[#2A2E35] font-tech text-[10px] text-slate-300">
                    HYDROFORMED 6061-T6 // REV 04
                  </div>
                </div>
                <div className="flex items-center justify-between font-tech text-xs text-slate-400 pt-1">
                  <span className="flex items-center gap-1.5 text-white font-semibold">
                    <ShieldCheck className="w-4 h-4 text-[#FF5500]" /> Single-Platform Focus
                  </span>
                  <span>DE-BY-2020-RC101</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3 Core Pillars */}
      <section className="w-full bg-[#16191F] py-20 px-4 sm:px-6 lg:px-12 border-t border-[#2A2E35]">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-12">
            <span className="font-tech text-xs text-[#FF5500] uppercase tracking-widest font-semibold block mb-2">
              // THE THREE PILLARS
            </span>
            <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl text-[#F4F5F7] uppercase font-extrabold">
              Engineering Orthodoxy, Not Industry Trends
            </h2>
            <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
              Mass cycling conglomerates release 30 variations annually to engineer synthetic obsolescence. We spend years relentlessly refining the same geometry, stripping out grams while doubling structural fatigue thresholds.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Pillar 1 */}
            <div className="p-8 rounded-2xl bg-[#0F1115] border border-[#2A2E35] hover:border-[#FF5500]/60 transition-all flex flex-col justify-between shadow-xl">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="font-tech text-xs font-bold text-[#FF5500] px-2 py-1 rounded bg-[#FF5500]/10 border border-[#FF5500]/30">
                    PILLAR 01
                  </span>
                  <Target className="w-6 h-6 text-[#FF5500]" />
                </div>
                <h3 className="font-display text-lg font-bold text-white uppercase mb-2">
                  Single-Model Dedication
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed mb-6">
                  We don't dilute our focus across 40 sku variations. Every euro of R&amp;D, every laser measuring calibration, and every downhill trail test cycle is directed solely into the RC 101 sports chassis.
                </p>
              </div>
              <div className="pt-4 border-t border-[#2A2E35] flex items-center justify-between font-tech text-xs">
                <span className="text-slate-400">R&amp;D CONCENTRATION</span>
                <span className="text-[#FF5500] font-bold">100% RC 101</span>
              </div>
            </div>

            {/* Pillar 2 */}
            <div className="p-8 rounded-2xl bg-[#0F1115] border border-[#2A2E35] hover:border-[#FF5500]/60 transition-all flex flex-col justify-between shadow-xl">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="font-tech text-xs font-bold text-[#FF5500] px-2 py-1 rounded bg-[#FF5500]/10 border border-[#FF5500]/30">
                    PILLAR 02
                  </span>
                  <Wrench className="w-6 h-6 text-[#FF5500]" />
                </div>
                <h3 className="font-display text-lg font-bold text-white uppercase mb-2">
                  German Precision Calibration
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed mb-6">
                  Laser-measured assembly tolerances below 0.02mm. Hydroformed aerospace-grade aluminum tubes stress-relieved via heat-treatment cycles and dyno-tested on multi-axis hydraulic torture rigs.
                </p>
              </div>
              <div className="pt-4 border-t border-[#2A2E35] flex items-center justify-between font-tech text-xs">
                <span className="text-slate-400">MAX RUNOUT DEVIATION</span>
                <span className="text-[#FF5500] font-bold">&lt; 0.018 MM</span>
              </div>
            </div>

            {/* Pillar 3 */}
            <div className="p-8 rounded-2xl bg-[#0F1115] border border-[#2A2E35] hover:border-[#FF5500]/60 transition-all flex flex-col justify-between shadow-xl">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="font-tech text-xs font-bold text-[#FF5500] px-2 py-1 rounded bg-[#FF5500]/10 border border-[#FF5500]/30">
                    PILLAR 03
                  </span>
                  <Layers className="w-6 h-6 text-[#FF5500]" />
                </div>
                <h3 className="font-display text-lg font-bold text-white uppercase mb-2">
                  Modular Longevity Ecosystem
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed mb-6">
                  Planned obsolescence is an engineering failure. Every pivot bearing, internal cable route port, and drop-out bracket on the RC 101 can be serviced with standard workshop hex tools and factory spare cartridges.
                </p>
              </div>
              <div className="pt-4 border-t border-[#2A2E35] flex items-center justify-between font-tech text-xs">
                <span className="text-slate-400">PARTS GUARANTEE</span>
                <span className="text-[#FF5500] font-bold">15-YR SUPPORT</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* The Munich Timeline */}
      <section id="heritage" className="w-full bg-[#0F1115] py-20 px-4 sm:px-6 lg:px-12 border-t border-[#2A2E35]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <span className="font-tech text-xs text-[#FF5500] uppercase tracking-widest font-semibold block mb-2">
                // CHRONOLOGY
              </span>
              <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl text-[#F4F5F7] uppercase font-extrabold">
                The Munich Timeline
              </h2>
            </div>
            <p className="text-sm text-slate-400 max-w-md">
              From an underground workshop prototype in Garching to Europe's most uncompromising downhill hardtail.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* 2020 */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-display text-3xl font-extrabold text-[#FF5500]">2020</span>
                  <span className="font-tech text-[10px] text-slate-400">MUNICH FOUNDING</span>
                </div>
                <h4 className="font-display text-base font-bold text-white uppercase mt-4">
                  The Anti-Portfolio Manifesto
                </h4>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  Two German aerospace engineers and downhill racers reject 30-bike product lines to build one single indestructible aluminum frameset.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] font-tech text-[11px] text-slate-400">
                <span className="text-white block font-bold">CHASSIS ALPHA 0.1</span>
                <span>Manual TIG-welded in small garage laboratory</span>
              </div>
            </div>

            {/* 2022 */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-display text-3xl font-extrabold text-slate-400">2022</span>
                  <span className="font-tech text-[10px] text-slate-400">DYNAMIC LABS</span>
                </div>
                <h4 className="font-display text-base font-bold text-white uppercase mt-4">
                  Hydraulic Rig Torture Tests
                </h4>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  Constructed custom high-frequency hydraulic fatigue actuators simulating 10,000 runs down the Bavarian Alps without structural micro-fissuring.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] font-tech text-[11px] text-slate-400">
                <span className="text-white block font-bold">2,500,000 CYCLES</span>
                <span>Zero frame weld fractures recorded</span>
              </div>
            </div>

            {/* 2024 */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-display text-3xl font-extrabold text-slate-400">2024</span>
                  <span className="font-tech text-[10px] text-slate-400">COMMERCIAL DEBUT</span>
                </div>
                <h4 className="font-display text-base font-bold text-white uppercase mt-4">
                  RC 101 Sports Edition
                </h4>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  Commercial launch of the RC 101 with signature Summit Blaze accents, white-wall 29" knobby tread setups, and Shimano 1x11 drivetrain.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] font-tech text-[11px] text-slate-400">
                <span className="text-white block font-bold">SOLD OUT BATCH 01</span>
                <span>Allocated in 72 hours across Europe</span>
              </div>
            </div>

            {/* 2026 */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-display text-3xl font-extrabold text-[#FF5500]">2026</span>
                  <span className="font-tech text-[10px] text-[#FF5500]">EXPANSION</span>
                </div>
                <h4 className="font-display text-base font-bold text-white uppercase mt-4">
                  Modular Parts Ecosystem
                </h4>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  Launch of our open-spec modular components ecosystem: bolt-on telemetry cages, cold-forged cranks, and direct consumer workshop spares.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] font-tech text-[11px] text-slate-400">
                <span className="text-white block font-bold">DIRECT GLOBAL SUPPLY</span>
                <span>24h factory replacement shipping</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Laboratory & Metallurgy Section */}
      <section className="w-full bg-[#16191F] py-20 px-4 sm:px-6 lg:px-12 border-t border-[#2A2E35]">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-6 space-y-4">
              <span className="font-tech text-xs text-[#FF5500] uppercase tracking-widest font-semibold block">
                // THE LAB
              </span>
              <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl text-[#F4F5F7] uppercase font-extrabold leading-tight">
                Where Aerospace Metallurgy Meets Downhill Gravity
              </h2>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                Our facility in southern Bavaria merges cleanroom precision with mountain ruggedness. We inspect raw 6061-T6 aluminum alloys via ultrasonic spectrometers before cutting a single millimeter of tubing.
              </p>

              <div className="space-y-3 pt-2 text-sm text-slate-300 font-medium">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#FF5500] flex-shrink-0" />
                  <span>Double-pass TIG welds ground smooth to eliminate stress risers</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#FF5500] flex-shrink-0" />
                  <span>Individual serial laser-etched directly into bottom bracket shell</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#FF5500] flex-shrink-0" />
                  <span>Zero single-use plastics: bikes ship in reusable CNC wooden flight crates</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 grid grid-cols-2 gap-4">
              <div className="rounded-xl overflow-hidden bg-[#0F1115] border border-[#2A2E35] h-60">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuAYhwhPIn7FXwVa5XvAuGTQMw9xI-FBJXEvpFbCZMqQ0qrCtVy94Gc09vwq9bW9EfkMyGfWyfY6T4L4GaFrA207yW3TNLdcIj1D1vniu4KfKMA_el8Tk4vljgLsz2xbvuASyDyY7VFgz6WuVXc_5X2gPoRem0UrHGXNtbIF6elvIHpcxhCJatM9o1KsXh-Bspb8p3-bUc26eh1emg0hMcFK7tKYG8csO3dpgwlUpS989bM2AJsWngKGtw"
                  alt="Aerospace TIG Welding Process"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="rounded-xl overflow-hidden bg-[#0F1115] border border-[#2A2E35] h-60 mt-6">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuAINVctI_Un4Zd3yxqaGnv0dQiUx5gVknQeqH4mZ1N6gvV4x5ivBWMvhfNEnB3UoeYIf5E8h7bbBtHvf4YwsYchD3gj7HA9SAQxJZM3P79HP3zwB4Q7Or_ZGtTd7MXPbL06Vvnr79dWDcKu68b2ttKGGayyG6iE1hanr3xGYIrDwVsaggHFEHJCvvcL6O7w01u6IyLabHwTtvlg-qJbC9_Qv1HwdXHBPHKn2pn9vJotjY4a09zb0BP3UQ"
                  alt="Laser Alignment & Quality Testing"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
          </div>

          {/* Metallurgy Metrics Strip */}
          <div className="rounded-2xl bg-[#0F1115] border border-[#2A2E35] p-6 sm:p-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-left">
              <div>
                <div className="font-tech text-xs text-slate-400 uppercase">METALLURGY</div>
                <div className="font-display text-lg sm:text-xl text-white font-bold mt-1">
                  AL 6061-T6 + SC
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">Scandium reinforced nodes</div>
              </div>
              <div>
                <div className="font-tech text-xs text-slate-400 uppercase">FATIGUE THRESHOLD</div>
                <div className="font-display text-lg sm:text-xl text-white font-bold mt-1">
                  3,000,000 STRIKES
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">3.4x over EN 14766</div>
              </div>
              <div>
                <div className="font-tech text-xs text-slate-400 uppercase">FINISH</div>
                <div className="font-display text-lg sm:text-xl text-white font-bold mt-1">
                  CERAMIC ANODIZE
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">9H scratch proof layer</div>
              </div>
              <div>
                <div className="font-tech text-xs text-slate-400 uppercase">ENERGY SOURCE</div>
                <div className="font-display text-lg sm:text-xl text-white font-bold mt-1">
                  100% HYDRO
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">Bavarian river turbines</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quote Callout */}
      <section className="w-full bg-[#0F1115] py-20 px-4 sm:px-6 lg:px-12 border-t border-[#2A2E35] text-center relative overflow-hidden">
        <div className="max-w-4xl mx-auto space-y-6 relative z-10">
          <div className="w-12 h-12 rounded-full bg-[#FF5500]/10 flex items-center justify-center text-[#FF5500] mx-auto">
            <Quote className="w-6 h-6" />
          </div>
          <blockquote className="font-display text-xl sm:text-2xl lg:text-3xl text-[#F4F5F7] font-semibold italic leading-relaxed">
            “If you design twenty different bicycle frames each season, you understand none of them deeply. We chose to build one frame so flawless, so stiff, and so dependable that your grandchildren will inherit it.”
          </blockquote>
          <div className="pt-4 flex items-center justify-center gap-4">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDSw0yAmcFqKKkW8ehKpw2Sp5kGmevSA4SjLZdKA_yOYudc4DxqFILmtCF0FJoRxfLSO4vvhH-uGIXHsnlI7bhLO-QAR_CWqU6oWVJxrtIn_m6anLL1dcUgvfUDmk_nj2qvKGy86i1Kr6GlskIUUJaF6xKt8TLM0AQrvA6cw_YCChuA02OX-ek4FDHsKyQZ2SzjxFjUoOuoSsMSq4wxwDwX9sUIog0x_gXpmg2F-_r173VLNMwZzMjgoA"
              alt="Dr. Markus von Bern"
              className="w-14 h-14 rounded-full object-cover border-2 border-[#FF5500]"
            />
            <div className="text-left">
              <div className="font-display text-sm font-bold uppercase text-white">
                Dr. Markus von Bern
              </div>
              <div className="font-tech text-xs text-[#FF5500]">
                CHIEF FRAME ARCHITECT • ROCK CLIMBER GMBH
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Visit the Assembly Works */}
      <section className="w-full bg-[#16191F] py-20 px-4 sm:px-6 lg:px-12 border-t border-[#2A2E35]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5 space-y-4">
            <span className="font-tech text-xs text-[#FF5500] uppercase tracking-widest font-semibold block">
              // MUNICH HQ &amp; FACTORY
            </span>
            <h2 className="font-display text-2xl sm:text-3xl text-[#F4F5F7] uppercase font-bold">
              Visit the Assembly Works
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Nestled directly at the doorstep of the Bavarian Alps, our engineering campus houses dynamic dynamometer benches, our custom paint shop, and direct access to alpine trial descents.
            </p>

            <div className="space-y-3 pt-2 text-xs font-tech">
              <div className="flex items-start gap-3 p-4 rounded-xl bg-[#0F1115] border border-[#2A2E35]">
                <MapPin className="w-5 h-5 text-[#FF5500] flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block">Rock Climber GmbH Technikum</strong>
                  <span className="text-slate-400">
                    Lilienthalallee 42, 80807 Munich, Bavaria, Germany
                  </span>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 rounded-xl bg-[#0F1115] border border-[#2A2E35]">
                <Clock className="w-5 h-5 text-[#FF5500] flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block">Tour Hours</strong>
                  <span className="text-slate-400">
                    Tuesday – Saturday: 09:00 – 18:00 CET (By reservation only)
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div
              className="w-full h-80 rounded-2xl bg-cover bg-center overflow-hidden relative shadow-2xl flex items-end p-6 border border-[#2A2E35]"
              style={{
                backgroundImage:
                  "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCZVO_r5OPQEU_q3bcaaKLbdHCOdNCaCkPVlgPqJmsw2bbS13buEsUTQNINYk2IfDEHzD-sv0-1LZOJ8otTRNDvhIgHPhhDr-M0tyvMqDyLam6gqpeN3DpRPeuhpuqfW_dbN6WOX_kguMajeHovAk3NDBZ5Olcoce3AB-vwcEExUslC9EozjMIqL3CNwBQL_FAS0Z4YXdPd63wqMJNqYF1RV4EDMY1nB0WsHrYCtIaFpgoAkxQZBTmryQ')"
              }}
            >
              <div className="rounded-xl bg-[#0F1115]/95 backdrop-blur-md p-4 flex items-center justify-between w-full shadow-lg border border-[#2A2E35]">
                <div className="flex items-center gap-3">
                  <span className="w-3 h-3 rounded-full bg-[#FF5500] animate-pulse" />
                  <div>
                    <div className="font-display text-xs text-white font-bold uppercase">
                      Alpine Proving Grounds
                    </div>
                    <div className="font-tech text-[10px] text-slate-400">
                      Trailhead #4 • 12km from Munich ring
                    </div>
                  </div>
                </div>
                <span className="font-tech text-xs text-[#FF5500] font-bold">48.1351° N</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Tour Modal */}
      {tourModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-[#16191F] border border-[#2A2E35] rounded-2xl shadow-2xl text-[#F4F5F7] p-6 sm:p-8 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-[#2A2E35]">
              <div>
                <span className="font-tech text-xs text-[#FF5500] uppercase font-bold tracking-widest">
                  // MUNICH TECHNIKUM ACCESS
                </span>
                <h3 className="font-display text-lg font-bold uppercase text-white mt-0.5">
                  Schedule Factory Tour &amp; Ride
                </h3>
              </div>
              <button
                onClick={() => setTourModalOpen(false)}
                className="w-8 h-8 rounded-full bg-[#0F1115] hover:bg-[#2A2E35] text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {tourSubmitted ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="font-display text-base font-bold text-white uppercase">
                  Reservation Telemetry Logged
                </h4>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  Our Munich engineering concierge will contact you within 4 hours to verify your pilot pass.
                </p>
              </div>
            ) : (
              <form onSubmit={handleTourSubmit} className="space-y-4 pt-4">
                <div>
                  <label className="font-tech text-xs text-slate-300 uppercase block mb-1">
                    Athlete / Engineer Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={tourForm.name}
                    onChange={(e) => setTourForm({ ...tourForm, name: e.target.value })}
                    placeholder="e.g. Dr. Felix Gruber"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-white focus:outline-none focus:border-[#FF5500]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="font-tech text-xs text-slate-300 uppercase block mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={tourForm.email}
                      onChange={(e) => setTourForm({ ...tourForm, email: e.target.value })}
                      placeholder="rider@domain.de"
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-white focus:outline-none focus:border-[#FF5500]"
                    />
                  </div>
                  <div>
                    <label className="font-tech text-xs text-slate-300 uppercase block mb-1">
                      Preferred Date *
                    </label>
                    <input
                      type="date"
                      required
                      value={tourForm.date}
                      onChange={(e) => setTourForm({ ...tourForm, date: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-white focus:outline-none focus:border-[#FF5500]"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-tech text-xs text-slate-300 uppercase block mb-1">
                    Rider Experience &amp; Damper Notes
                  </label>
                  <textarea
                    rows={3}
                    value={tourForm.riderNote}
                    onChange={(e) => setTourForm({ ...tourForm, riderNote: e.target.value })}
                    placeholder="Provide your height (e.g. 182cm), trail riding style, or any specific telemetry interest..."
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-white focus:outline-none focus:border-[#FF5500] resize-none"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setTourModalOpen(false)}
                    className="px-4 py-2 font-tech text-xs text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider hover:scale-105 transition-transform"
                  >
                    Confirm Tour Slot
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
