import React from 'react';
import {
  FileText,
  ShieldCheck,
  Truck,
  RotateCcw,
  Scale,
  Award,
  CheckCircle2,
  AlertTriangle,
  Building
} from 'lucide-react';

export const TermsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[var(--bg-main)] text-[var(--text-primary)] transition-colors duration-300">
      {/* Header */}
      <section className="relative pt-32 pb-16 border-b border-[var(--border-color)] overflow-hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-orange-500/30 bg-orange-500/10 text-orange-500 text-xs font-mono font-medium tracking-wider mb-4">
            <FileText className="w-3.5 h-3.5" />
            LEGAL JURISDICTION // FEDERAL REPUBLIC OF GERMANY
          </div>
          <h1 className="text-4xl md:text-5xl font-black uppercase tracking-tight text-[var(--text-primary)] mb-4">
            Terms & Conditions <br />
            <span className="text-orange-500 font-extrabold">& Warranty Standards</span>
          </h1>
          <p className="text-sm sm:text-base text-[var(--text-secondary)]">
            Effective Date: January 1, 2026. Governing transactions, 5-Year Frame Warranty, safety certifications, and logistics for Rock Climber GmbH, Munich, Germany.
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          {/* Quick Legal Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-color)]">
              <ShieldCheck className="w-6 h-6 text-orange-500 mb-3" />
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-primary)]">
                5-Year Frame Warranty
              </h3>
              <p className="text-xs text-[var(--text-secondary)] mt-1">
                Covers structural fatigue, welds, and catastrophic failure under normal sports use.
              </p>
            </div>
            <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-color)]">
              <RotateCcw className="w-6 h-6 text-orange-500 mb-3" />
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-primary)]">
                30-Day Trail Trial
              </h3>
              <p className="text-xs text-[var(--text-secondary)] mt-1">
                Ride the RC 101 on your home trails. If unsatisfied, return with our prepaid Bavarian shipping crate.
              </p>
            </div>
            <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-color)]">
              <Scale className="w-6 h-6 text-orange-500 mb-3" />
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-primary)]">
                German BGB & DIN/ISO
              </h3>
              <p className="text-xs text-[var(--text-secondary)] mt-1">
                Governed under the German Civil Code (BGB) and DIN EN ISO 4210 mountain bike testing standards.
              </p>
            </div>
          </div>

          {/* Section 1 */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[var(--text-primary)] flex items-center gap-2">
              <span className="text-orange-500 font-mono text-sm">§ 1</span>
              General Scope & Company Information
            </h2>
            <div className="text-sm text-[var(--text-secondary)] space-y-3 leading-relaxed">
              <p>
                These General Terms and Conditions (AGB) apply to all sales, contracts, and delivery of bicycles, components, and accessories ordered via the website or direct order portal of:
              </p>
              <div className="p-4 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-color)] font-mono text-xs text-[var(--text-primary)] space-y-1">
                <p className="font-bold">Rock Climber GmbH</p>
                <p>Leopoldstraße 142, 80804 Munich, Bavaria, Germany</p>
                <p>Commercial Register: Amtsgericht München HRB 265891</p>
                <p>Managing Director: Dipl.-Ing. Jens Lindner</p>
                <p>VAT ID (USt-IdNr.): DE 349 821 760</p>
              </div>
              <p>
                Deviating or contradictory terms of the customer will not be recognized unless expressly approved in writing by Rock Climber GmbH management.
              </p>
            </div>
          </div>

          {/* Section 2: 5-Year Warranty */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[var(--text-primary)] flex items-center gap-2">
              <span className="text-orange-500 font-mono text-sm">§ 2</span>
              5-Year Frame Guarantee & Component Warranties
            </h2>
            <div className="text-sm text-[var(--text-secondary)] space-y-3 leading-relaxed">
              <p>
                In addition to the mandatory statutory 2-year warranty under German law (§ 437 BGB), Rock Climber GmbH grants the first original owner a voluntary <strong className="text-[var(--text-primary)]">5-Year Manufacturer Frame Guarantee</strong>:
              </p>
              <ul className="list-disc list-inside space-y-1.5 pl-2 text-xs sm:text-sm text-[var(--text-primary)]">
                <li>Coverage includes structural cracks, tube wall failure, and weld delamination on all hydroformed 6061-T6 alloy frames.</li>
                <li>OEM suspension components (e.g. RST Blaze 100mm) and Shimano hydraulic drivetrain modules retain full 24-month manufacturer warranties.</li>
                <li>Normal wear and tear (brake pads, tire tread, derailleur cables, chains) is excluded from warranty unless defects are reported within 14 days of delivery.</li>
                <li>The guarantee remains valid provided annual torque calibration specs (detailed in the owner manual) are maintained.</li>
              </ul>
            </div>
          </div>

          {/* Section 3: Shipping & Logistics */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[var(--text-primary)] flex items-center gap-2">
              <span className="text-orange-500 font-mono text-sm">§ 3</span>
              Delivery, Assembly & Transport Damage
            </h2>
            <div className="text-sm text-[var(--text-secondary)] space-y-3 leading-relaxed">
              <p>
                The RC 101 is delivered 95% pre-assembled inside our specialized heavy-duty Bavarian cardboard freight crate. The rider must only straighten the cockpit (4-bolt faceplate, 5 Nm) and install pedals before riding.
              </p>
              <p>
                We partner with DHL Freight Bavaria and DB Schenker for insured tracked transit. Please inspect the outer container immediately upon receipt. Any obvious transport puncture or deformation must be confirmed by the delivery driver on the consignment slip.
              </p>
            </div>
          </div>

          {/* Section 4: Revocation */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[var(--text-primary)] flex items-center gap-2">
              <span className="text-orange-500 font-mono text-sm">§ 4</span>
              Right of Revocation & 30-Day Trail Trial
            </h2>
            <div className="text-sm text-[var(--text-secondary)] space-y-3 leading-relaxed">
              <p>
                EU consumers have a statutory 14-day right of revocation. Rock Climber GmbH voluntarily extends this policy to a <strong className="text-[var(--text-primary)]">30-Day Trial Period</strong> for the flagship RC 101.
              </p>
              <p>
                To initiate a return, contact <code className="text-orange-500">service@rockclimber.de</code>. We will arrange scheduled DHL freight pickup at your door. The bicycle must be re-packed into the provided original crate with all tools and manuals.
              </p>
            </div>
          </div>

          {/* Section 5: Governing Law */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold uppercase tracking-tight text-[var(--text-primary)] flex items-center gap-2">
              <span className="text-orange-500 font-mono text-sm">§ 5</span>
              Applicable Law & Place of Jurisdiction
            </h2>
            <div className="text-sm text-[var(--text-secondary)] space-y-3 leading-relaxed">
              <p>
                The laws of the Federal Republic of Germany apply, excluding the UN Convention on Contracts for the International Sale of Goods (CISG).
              </p>
              <p>
                For commercial merchants and legal entities under public law, the exclusive place of jurisdiction for all disputes arising from this contract is <strong className="text-[var(--text-primary)]">Munich (München), Germany</strong>.
              </p>
            </div>
          </div>

        </div>
      </section>
    </div>
  );
};
