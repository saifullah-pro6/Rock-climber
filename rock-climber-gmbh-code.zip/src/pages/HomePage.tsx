import React, { useState } from 'react';
import { FrameSize, Hotspot } from '../types';
import { HOTSPOTS } from '../data/hotspots';
import {
  Grid,
  RotateCcw,
  Ruler,
  ShoppingBag,
  ArrowDown,
  Shield,
  Award,
  Truck,
  CheckCircle2,
  Maximize2
} from 'lucide-react';

interface HomePageProps {
  selectedSize: FrameSize;
  onSelectSize: (size: FrameSize) => void;
  onOpenOrderModal: () => void;
  onOpenSizeGuide: () => void;
  onNavigateToShop: () => void;
  onNavigateToContact: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  selectedSize,
  onSelectSize,
  onOpenOrderModal,
  onOpenSizeGuide,
  onNavigateToShop,
  onNavigateToContact
}) => {
  const [activeHotspot, setActiveHotspot] = useState<Hotspot | null>(null);
  const [isGridActive, setIsGridActive] = useState(false);
  const [backdropMode, setBackdropMode] = useState<'stealth' | 'proving-yellow'>('stealth');

  // Images for RC 101
  const darkStudioImg =
    'https://lh3.googleusercontent.com/aida-public/AB6AXuCe3-EeIBGGdkLFD0Q_vU_40AlKtOKFGxL7ALnNyqDDOe3101zLnyu4SIoL6ZwCULlEwXeXhh-jcBRkjmXDqp8IfGZvJdBjUHaozjpYn0JST89ldCN-HVNkVeMIY7d9SjGQk__LvQUmqthtYbwYvT19AARJ2GOZQLNiMTcLLKACcPZFqFfl_jxApwUvGml-qpj9KJ-2BEB81UZC2yXDxh6zKWkhTRSJV1SPQpSWJPMHrr8zp4pKNzrJ0g';
  const yellowProvingImg =
    'https://lh3.googleusercontent.com/aida-public/AB6AXuDhU6Jemip8e7NI6HF0XErlASgfQYG_T1BZzChdr9N4gD6AWp7Q5aVaCRHTR65GTUb_rlSsDH_kg2nj-7DWTQLLN0Df5En4CqEG85IzxAjsrCwmuSxFljvpgqv03N8vUWmND8HzsZSTLrJCZSM9-E4wgmsk1So6zl5932ZMlkM6l5LR6BD4AHdeklZmrUBKSESmIUBt8XfyFLgJOjHZ1d2h-Ujs1eaT_NqvTDdDMoexQ-8dH2V1-3nmYA';

  const handleHotspotClick = (spot: Hotspot) => {
    setActiveHotspot(activeHotspot?.id === spot.id ? null : spot);
  };

  const handleResetFocal = () => {
    setActiveHotspot(null);
  };

  return (
    <div className="flex flex-col w-full">
      {/* Top Technical Status Marquee */}
      <section className="w-full bg-[#0C0E12] border-b border-[#2A2E35] py-2 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 font-tech text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <span className="inline-block w-2 h-2 rounded-full bg-[#FF5500] animate-ping" />
            <span className="text-white font-semibold tracking-wider">
              PRODUCTION ALLOCATION 2026: ACTIVE
            </span>
            <span className="text-slate-600 hidden sm:inline">|</span>
            <span className="hidden sm:inline">SERIES NO: RC-101-GER-SPORTS</span>
          </div>
          <div className="flex items-center gap-4 sm:gap-6 text-[11px] sm:text-xs">
            <span className="text-[#FF5500] font-bold">
              LIMITED BATCH RUN (34/100 ALLOCATED)
            </span>
            <span className="hidden md:inline text-slate-400">
              FACTORY: MUNICH, BAVARIA
            </span>
          </div>
        </div>
      </section>

      {/* Hero & Blueprint Stage */}
      <section className="relative w-full overflow-hidden bg-[#0F1115] pt-10 sm:pt-14 pb-20 px-4 sm:px-6 lg:px-12">
        {/* Subtle Ambient Glow and Blueprint Texture */}
        <div
          className={`absolute inset-0 pointer-events-none transition-opacity duration-300 ${
            isGridActive ? 'opacity-40 cad-dots-active' : 'opacity-15 cad-grid-dark'
          }`}
        />
        <div className="absolute -top-32 right-1/4 w-96 h-96 bg-[#FF5500]/10 rounded-full blur-[140px] pointer-events-none" />

        <div className="max-w-7xl mx-auto flex flex-col relative z-10">
          {/* Overline & Typography */}
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-8">
            <div className="max-w-3xl">
              <div className="flex items-center gap-3 mb-4">
                <span className="px-2.5 py-1 rounded bg-[#16191F] border border-[#2A2E35] font-tech text-xs text-[#FF5500] uppercase tracking-widest font-semibold">
                  Flagship Hardtail • Sports Edition
                </span>
                <span className="font-tech text-xs text-slate-400 tracking-wider">
                  REV. 04 // 2026
                </span>
              </div>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl text-[#F4F5F7] uppercase tracking-tight leading-[1.05] font-extrabold">
                Engineered for the Ridge. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF5500] via-[#ff884d] to-white">
                  Built for Speed.
                </span>
              </h1>
              <p className="mt-4 sm:mt-5 text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
                German precision metallurgy meets high-tensile alpine endurance. Experience the surgical agility of our hydroformed 6061-T6 monocoque chassis paired with race-calibrated Shimano gearing.
              </p>
            </div>

            {/* MSRP Callout Card */}
            <div className="flex lg:flex-col items-end gap-3 bg-[#16191F]/90 p-5 rounded-2xl border border-[#2A2E35] backdrop-blur-md shadow-xl flex-shrink-0">
              <div className="text-right">
                <div className="font-tech text-xs text-slate-400 uppercase tracking-wider">
                  MSRP Net Europe
                </div>
                <div className="font-display text-3xl sm:text-4xl text-[#F4F5F7] font-black leading-tight">
                  €2,499<span className="text-[#FF5500] text-xl font-normal">.00</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-[#FF5500]/20 text-[#FF5500] font-tech text-[10px] font-bold uppercase tracking-wider">
                  Ready to Ship
                </span>
                <span className="text-slate-400 font-tech text-xs">Direct from Munich</span>
              </div>
            </div>
          </div>

          {/* Interactive 3D / Blueprint Hotspot Canvas Stage */}
          <div className="relative w-full rounded-2xl bg-[#16191F] border border-[#2A2E35] overflow-hidden shadow-2xl p-4 sm:p-6 lg:p-8">
            {/* Stage Controls Bar */}
            <div className="flex flex-wrap items-center justify-between pb-4 sm:pb-6 border-b border-[#2A2E35] gap-3">
              <div className="flex items-center gap-2 font-tech text-xs text-slate-400">
                <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#FF5500] animate-pulse" />
                <span className="text-white font-semibold">VIEWPORT: CHASSIS TELEMETRY</span>
                <span className="text-slate-600 hidden sm:inline">•</span>
                <span className="hidden sm:inline">5 INTERACTIVE HOTSPOTS [CLICK TO INSPECT]</span>
              </div>

              <div className="flex items-center gap-2">
                {/* Backdrop Switcher */}
                <div className="flex items-center bg-[#0F1115] rounded-lg p-1 border border-[#2A2E35] text-xs font-tech">
                  <button
                    onClick={() => setBackdropMode('stealth')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      backdropMode === 'stealth'
                        ? 'bg-[#FF5500] text-white font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Stealth Slate
                  </button>
                  <button
                    onClick={() => setBackdropMode('proving-yellow')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      backdropMode === 'proving-yellow'
                        ? 'bg-[#FF5500] text-white font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Munich Proving Track
                  </button>
                </div>

                {/* Blueprint Grid Toggle */}
                <button
                  onClick={() => setIsGridActive(!isGridActive)}
                  className={`px-3 py-1.5 rounded-lg border font-tech text-xs transition-all flex items-center gap-1.5 cursor-pointer ${
                    isGridActive
                      ? 'border-[#FF5500] text-[#FF5500] bg-[#FF5500]/10'
                      : 'border-[#2A2E35] bg-[#0F1115] text-slate-300 hover:border-slate-500'
                  }`}
                  aria-label="Toggle CAD Blueprint Grid"
                >
                  <Grid className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Blueprint Grid</span>
                </button>

                {/* Reset Focal */}
                <button
                  onClick={handleResetFocal}
                  className="px-3 py-1.5 rounded-lg border border-[#2A2E35] bg-[#0F1115] hover:border-slate-500 font-tech text-xs text-slate-300 transition-all flex items-center gap-1.5 cursor-pointer"
                  aria-label="Reset Hotspot Focus"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Reset Focal</span>
                </button>
              </div>
            </div>

            {/* Stage Canvas Area */}
            <div
              className={`relative w-full min-h-[380px] sm:min-h-[480px] lg:min-h-[580px] flex items-center justify-center py-6 select-none transition-all duration-300 rounded-xl overflow-hidden ${
                backdropMode === 'proving-yellow' ? 'bg-[#ffcc00]/10' : 'bg-[#0C0E12]'
              }`}
            >
              {/* CAD Crosshair Coordinate Lines */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-15">
                <div className="w-full h-[1px] bg-slate-300" />
                <div className="absolute h-full w-[1px] bg-slate-300" />
              </div>

              {/* Master Bike Image */}
              <div className="relative max-w-4xl w-full mx-auto flex items-center justify-center px-4">
                <img
                  src={backdropMode === 'stealth' ? darkStudioImg : yellowProvingImg}
                  alt="Rock Climber RC 101 Sports Edition Flagship Mountain Bike"
                  className="w-full h-auto object-contain max-h-[500px] filter drop-shadow-[0_20px_45px_rgba(0,0,0,0.85)] z-10 transition-all duration-500"
                />

                {/* 5 Interactive Hotspots */}
                {HOTSPOTS.map((spot) => {
                  const isActive = activeHotspot?.id === spot.id;
                  return (
                    <div
                      key={spot.id}
                      style={{ top: spot.position.top, left: spot.position.left }}
                      className="absolute z-20 -translate-x-1/2 -translate-y-1/2"
                    >
                      <button
                        onClick={() => handleHotspotClick(spot)}
                        aria-label={`Hotspot 0${spot.id}: ${spot.title}`}
                        className={`relative flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-[#0F1115]/95 border shadow-lg transition-transform duration-300 cursor-pointer ${
                          isActive
                            ? 'scale-125 border-[#FF5500] ring-4 ring-[#FF5500]/30 shadow-[0_0_24px_rgba(255,85,0,0.8)]'
                            : 'border-[#FF5500]/70 hover:scale-110 hover:border-[#FF5500]'
                        }`}
                      >
                        <span className="absolute inline-flex h-full w-full rounded-full bg-[#FF5500] opacity-60 animate-ping" />
                        <span className="relative font-tech text-xs font-bold text-white">
                          0{spot.id}
                        </span>
                      </button>

                      {/* Active Popover Card */}
                      {isActive && (
                        <div className="absolute bottom-12 -left-28 sm:-left-36 w-64 sm:w-72 p-4 rounded-xl bg-[#0F1115]/95 border border-[#FF5500]/60 backdrop-blur-xl shadow-2xl z-30 animate-in zoom-in-95 duration-200">
                          <div className="flex items-center justify-between pb-2 border-b border-[#2A2E35]">
                            <span className="font-tech text-[10px] text-[#FF5500] uppercase font-bold tracking-wider">
                              {spot.category}
                            </span>
                            <span className="font-tech text-[10px] text-slate-400">
                              {spot.code}
                            </span>
                          </div>
                          <h4 className="font-display text-xs font-bold text-white mt-2 uppercase">
                            {spot.title}
                          </h4>
                          <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                            {spot.description}
                          </p>
                          <div className="mt-3 grid grid-cols-2 gap-1.5 font-tech text-[9px] text-slate-300">
                            {spot.specs.map((s, idx) => (
                              <div
                                key={idx}
                                className="px-1.5 py-1 bg-[#16191F] rounded border border-[#2A2E35]"
                              >
                                <span className="text-slate-500 block">{s.label}:</span>
                                <span className="text-white font-bold">{s.value}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Active Hotspot Telemetry Live Banner */}
              <div className="absolute bottom-3 left-3 right-3 sm:left-6 sm:right-auto sm:max-w-lg bg-[#0F1115]/95 border border-[#2A2E35] p-3 rounded-xl backdrop-blur-md flex items-center justify-between gap-4 z-20 shadow-lg">
                <div className="flex items-center gap-2.5 overflow-hidden">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#FF5500] flex-shrink-0 animate-pulse" />
                  <div className="truncate">
                    {activeHotspot ? (
                      <span className="font-tech text-xs text-white font-bold">
                        <span className="text-[#FF5500]">0{activeHotspot.id} // </span>
                        {activeHotspot.title.toUpperCase()}
                      </span>
                    ) : (
                      <span className="font-tech text-xs text-slate-300">
                        CLICK HOTSPOTS 01–05 FOR CAD TELEMETRY &amp; SPECS
                      </span>
                    )}
                  </div>
                </div>
                <span className="font-tech text-[10px] text-slate-400 flex-shrink-0 bg-[#16191F] px-2 py-0.5 rounded border border-[#2A2E35]">
                  5 GAUGES
                </span>
              </div>
            </div>

            {/* Frame Size Selector & Actions Deck */}
            <div className="mt-6 sm:mt-8 pt-6 sm:pt-8 border-t border-[#2A2E35] flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-6">
              {/* Size Selector */}
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="font-tech text-xs text-slate-300 uppercase tracking-wider font-semibold">
                    Select Frame Size &amp; Rider Geometry
                  </span>
                  <button
                    type="button"
                    onClick={onOpenSizeGuide}
                    className="font-tech text-xs text-[#FF5500] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Ruler className="w-3.5 h-3.5" />
                    <span>Fit Calculator</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { size: 'S' as FrameSize, inch: '15"', range: '155–168 cm', tag: 'IN STOCK' },
                    { size: 'M' as FrameSize, inch: '17"', range: '168–178 cm', tag: 'FEW LEFT' },
                    { size: 'L' as FrameSize, inch: '19"', range: '178–188 cm', tag: 'POPULAR' },
                    { size: 'XL' as FrameSize, inch: '21"', range: '188+ cm', tag: 'READY' }
                  ].map((s) => {
                    const isSelected = selectedSize === s.size;
                    return (
                      <button
                        key={s.size}
                        type="button"
                        onClick={() => onSelectSize(s.size)}
                        className={`px-4 py-3 rounded-xl border text-left transition-all cursor-pointer ${
                          isSelected
                            ? 'border-[#FF5500] bg-[#FF5500]/10 shadow-[0_0_15px_rgba(255,85,0,0.2)]'
                            : 'border-[#2A2E35] bg-[#0F1115] hover:border-slate-500'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-display font-bold text-base text-white">
                            {s.size} / {s.inch}
                          </span>
                          <span className="font-tech text-[9px] text-[#FF5500] font-bold">
                            {s.tag}
                          </span>
                        </div>
                        <div className="font-tech text-[10px] text-slate-400 mt-0.5">
                          {s.range}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 xl:pl-6">
                <button
                  type="button"
                  onClick={onOpenOrderModal}
                  className="px-8 py-4 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider shadow-[0_12px_32px_rgba(255,85,0,0.38)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer text-center"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Order RC 101 (€2,499)</span>
                </button>

                <a
                  href="#blueprint-specs"
                  className="px-6 py-4 rounded-full border border-[#2A2E35] bg-[#0F1115] text-[#F4F5F7] hover:border-[#FF5500] hover:text-[#FF5500] font-display text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 text-center"
                >
                  <span>Explore Specs</span>
                  <ArrowDown className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>

          {/* 3 Core Trust Badges */}
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="flex items-center gap-4 p-4 rounded-xl bg-[#16191F] border border-[#2A2E35]">
              <div className="w-10 h-10 rounded-xl bg-[#1E222B] flex items-center justify-center text-[#FF5500] flex-shrink-0">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <div className="font-display text-xs font-bold uppercase text-white">
                  Handcrafted in Germany
                </div>
                <div className="text-xs text-slate-400">Munich test lab stress certified</div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-xl bg-[#16191F] border border-[#2A2E35]">
              <div className="w-10 h-10 rounded-xl bg-[#1E222B] flex items-center justify-center text-[#FF5500] flex-shrink-0">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <div className="font-display text-xs font-bold uppercase text-white">
                  ISO 4210 Downhill Compliant
                </div>
                <div className="text-xs text-slate-400">Extreme condition impact rating</div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-xl bg-[#16191F] border border-[#2A2E35]">
              <div className="w-10 h-10 rounded-xl bg-[#1E222B] flex items-center justify-center text-[#FF5500] flex-shrink-0">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <div className="font-display text-xs font-bold uppercase text-white">
                  Express Worldwide Freight
                </div>
                <div className="text-xs text-slate-400">Shock-crated 98% pre-assembled</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Factory Blueprint Specifications Matrix */}
      <section
        id="blueprint-specs"
        className="w-full bg-[#0C0E12] border-t border-[#2A2E35] py-20 px-4 sm:px-6 lg:px-12 relative"
      >
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <div className="flex items-center gap-2 font-tech text-xs text-[#FF5500] uppercase tracking-widest font-semibold mb-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF5500]" />
                Telemetry &amp; Component Architecture
              </div>
              <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl text-[#F4F5F7] uppercase tracking-tight font-extrabold">
                Factory Blueprint Specifications
              </h2>
            </div>
            <p className="text-sm text-slate-400 max-w-md">
              Zero-tolerance machining tolerances. Every subassembly is recorded by serial number with DIN ISO-traceable quality logs.
            </p>
          </div>

          {/* 6 Key Spec Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Spec 1: Mass */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] hover:border-[#FF5500]/60 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between font-tech text-xs text-slate-400">
                  <span>PARAM: WEIGHT_NET</span>
                  <span className="text-[#FF5500] font-bold">SYS_01</span>
                </div>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-4xl text-white font-extrabold">14.2</span>
                  <span className="font-display text-xl text-[#FF5500] font-bold">KG</span>
                </div>
                <h3 className="font-display text-sm font-bold uppercase text-white mt-2">
                  Ultra-Tough Mass Ratio
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Optimized hardtail weight balance. Calibrated for instant sprint acceleration and high-speed downhill poise.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] flex items-center justify-between font-tech text-xs text-slate-400">
                <span>Payload Limit</span>
                <span className="text-white font-bold">130 kg Total</span>
              </div>
            </div>

            {/* Spec 2: Wheelset */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] hover:border-[#FF5500]/60 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between font-tech text-xs text-slate-400">
                  <span>PARAM: WHEELSET_29</span>
                  <span className="text-[#FF5500] font-bold">SYS_02</span>
                </div>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-4xl text-white font-extrabold">29"</span>
                  <span className="font-display text-xl text-[#FF5500] font-bold">KNOBBY</span>
                </div>
                <h3 className="font-display text-sm font-bold uppercase text-white mt-2">
                  White-Sidewall All-Terrain
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Double-wall reinforced eyelet rims engineered to absorb catastrophic rock strikes without rim bead distortion.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] flex items-center justify-between font-tech text-xs text-slate-400">
                <span>Tire Width</span>
                <span className="text-white font-bold">2.35" High-Traction</span>
              </div>
            </div>

            {/* Spec 3: Brakes */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] hover:border-[#FF5500]/60 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between font-tech text-xs text-slate-400">
                  <span>PARAM: BRAKE_TORQUE</span>
                  <span className="text-[#FF5500] font-bold">SYS_03</span>
                </div>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-4xl text-white font-extrabold">180</span>
                  <span className="font-display text-xl text-[#FF5500] font-bold">MM</span>
                </div>
                <h3 className="font-display text-sm font-bold uppercase text-white mt-2">
                  Shimano Hydraulic Disc
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Mineral oil hydraulic calipers with heat-dissipating centerlock directional alloy rotors for fade-free Alpine descents.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] flex items-center justify-between font-tech text-xs text-slate-400">
                <span>Rotor Mount</span>
                <span className="text-white font-bold">Centerlock Spline</span>
              </div>
            </div>

            {/* Spec 4: Drivetrain */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] hover:border-[#FF5500]/60 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between font-tech text-xs text-slate-400">
                  <span>PARAM: RATIO_GEARING</span>
                  <span className="text-[#FF5500] font-bold">SYS_04</span>
                </div>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-4xl text-white font-extrabold">1x11</span>
                  <span className="font-display text-xl text-[#FF5500] font-bold">SPEED</span>
                </div>
                <h3 className="font-display text-sm font-bold uppercase text-white mt-2">
                  Shimano Shadow RD+
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Single narrow-wide CNC chainring eliminates front derailleur drops while covering a 418% steep-ascent climbing ratio.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] flex items-center justify-between font-tech text-xs text-slate-400">
                <span>Range Spread</span>
                <span className="text-white font-bold">11-46 Tooth</span>
              </div>
            </div>

            {/* Spec 5: Load Limit */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] hover:border-[#FF5500]/60 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between font-tech text-xs text-slate-400">
                  <span>PARAM: LOAD_LIMIT</span>
                  <span className="text-[#FF5500] font-bold">SYS_05</span>
                </div>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-4xl text-white font-extrabold">130</span>
                  <span className="font-display text-xl text-[#FF5500] font-bold">KG MAX</span>
                </div>
                <h3 className="font-display text-sm font-bold uppercase text-white mt-2">
                  Reinforced Structural Load
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Reinforced seatpost collar and gusseted chainstays allow extreme downhill rider payload plus expedition bikepacking gear.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] flex items-center justify-between font-tech text-xs text-slate-400">
                <span>Fatigue Standard</span>
                <span className="text-white font-bold">EN 14766 Verified</span>
              </div>
            </div>

            {/* Spec 6: Warranty */}
            <div className="p-6 rounded-2xl bg-[#16191F] border border-[#2A2E35] hover:border-[#FF5500]/60 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between font-tech text-xs text-slate-400">
                  <span>PARAM: WARRANTY_LIFE</span>
                  <span className="text-[#FF5500] font-bold">SYS_06</span>
                </div>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-4xl text-white font-extrabold">05</span>
                  <span className="font-display text-xl text-[#FF5500] font-bold">YEARS</span>
                </div>
                <h3 className="font-display text-sm font-bold uppercase text-white mt-2">
                  Factory Chassis Guarantee
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Comprehensive structural failure coverage backed by Rock Climber GmbH direct replacement protocol across Europe.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#2A2E35] flex items-center justify-between font-tech text-xs text-slate-400">
                <span>Transferable</span>
                <span className="text-white font-bold">Yes • Registered Pass</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Frame Geometry Chart Table */}
      <section className="w-full bg-[#0F1115] py-20 px-4 sm:px-6 lg:px-12 border-t border-[#2A2E35]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-8 gap-4">
            <div>
              <span className="font-tech text-xs text-[#FF5500] uppercase tracking-widest font-semibold">
                Downhill / Trail Dynamics
              </span>
              <h3 className="font-display text-2xl sm:text-3xl text-[#F4F5F7] uppercase font-bold mt-1">
                Frame Geometry Chart (RC 101)
              </h3>
            </div>
            <div className="font-tech text-xs text-slate-400">
              MEASUREMENTS IN MILLIMETERS (MM) UNLESS SPECIFIED • HIGHLIGHTING ACTIVE SIZE: <span className="text-[#FF5500] font-bold">{selectedSize}</span>
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-[#2A2E35] bg-[#16191F]">
            <table className="w-full text-left font-tech text-xs">
              <thead className="bg-[#0C0E12] border-b border-[#2A2E35] text-slate-400 uppercase">
                <tr>
                  <th className="py-4 px-6 font-semibold">Geometry Dimension</th>
                  <th className={`py-4 px-6 ${selectedSize === 'S' ? 'text-[#FF5500] font-bold bg-[#FF5500]/10' : 'text-slate-300'}`}>
                    S (15")
                  </th>
                  <th className={`py-4 px-6 ${selectedSize === 'M' ? 'text-[#FF5500] font-bold bg-[#FF5500]/10' : 'text-slate-300'}`}>
                    M (17")
                  </th>
                  <th className={`py-4 px-6 ${selectedSize === 'L' ? 'text-[#FF5500] font-bold bg-[#FF5500]/10' : 'text-slate-300'}`}>
                    L (19") [TESTED]
                  </th>
                  <th className={`py-4 px-6 ${selectedSize === 'XL' ? 'text-[#FF5500] font-bold bg-[#FF5500]/10' : 'text-slate-300'}`}>
                    XL (21")
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2A2E35]/60 text-slate-300">
                {[
                  { label: 'A • Top Tube Horizontal', s: '585 mm', m: '605 mm', l: '625 mm', xl: '645 mm' },
                  { label: 'B • Seat Tube Length', s: '380 mm', m: '432 mm', l: '482 mm', xl: '533 mm' },
                  { label: 'C • Head Tube Angle', s: '67.5°', m: '67.5°', l: '67.5°', xl: '67.5°' },
                  { label: 'D • Seat Tube Angle', s: '74.5°', m: '74.5°', l: '74.5°', xl: '74.5°' },
                  { label: 'E • Chainstay Length', s: '435 mm', m: '435 mm', l: '435 mm', xl: '435 mm' },
                  { label: 'F • Wheelbase', s: '1115 mm', m: '1136 mm', l: '1158 mm', xl: '1180 mm' },
                  { label: 'G • Bottom Bracket Drop', s: '60 mm', m: '60 mm', l: '60 mm', xl: '60 mm' }
                ].map((row, idx) => (
                  <tr key={idx} className="hover:bg-[#1E222B]/50 transition-colors">
                    <td className="py-3.5 px-6 font-semibold text-white">{row.label}</td>
                    <td className={`py-3.5 px-6 ${selectedSize === 'S' ? 'text-[#FF5500] font-bold bg-[#FF5500]/5' : ''}`}>
                      {row.s}
                    </td>
                    <td className={`py-3.5 px-6 ${selectedSize === 'M' ? 'text-[#FF5500] font-bold bg-[#FF5500]/5' : ''}`}>
                      {row.m}
                    </td>
                    <td className={`py-3.5 px-6 ${selectedSize === 'L' ? 'text-[#FF5500] font-bold bg-[#FF5500]/5' : ''}`}>
                      {row.l}
                    </td>
                    <td className={`py-3.5 px-6 ${selectedSize === 'XL' ? 'text-[#FF5500] font-bold bg-[#FF5500]/5' : ''}`}>
                      {row.xl}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Direct Alpine Logistics Callout Box */}
      <section className="w-full bg-[#16191F] py-20 px-4 sm:px-6 lg:px-12 border-t border-[#2A2E35]">
        <div className="max-w-7xl mx-auto rounded-3xl bg-[#0F1115] border border-[#2A2E35] p-8 lg:p-14 relative overflow-hidden shadow-2xl">
          <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-[#FF5500]/20 rounded-full blur-[100px] pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-8 space-y-4">
              <div className="flex items-center gap-2 font-tech text-xs text-[#FF5500] uppercase tracking-widest font-semibold">
                <span className="w-2 h-2 rounded-full bg-[#FF5500]" />
                Direct Alpine Logistics // Proving Ground Handover
              </div>
              <h3 className="font-display text-2xl sm:text-3xl lg:text-4xl text-[#F4F5F7] uppercase font-extrabold">
                Ready to Conquer the Mountain?
              </h3>
              <p className="text-base text-slate-300 max-w-xl leading-relaxed">
                Order directly from Rock Climber GmbH Munich. Every RC 101 arrives in custom heavy-duty bike vault packaging with torque wrench set and factory setup certificate.
              </p>
              <div className="flex flex-wrap gap-4 font-tech text-xs text-slate-400 pt-2">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-[#FF5500]" /> 14-Day Mountain Trial
                </span>
                <span className="flex items-center gap-1.5 text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-[#FF5500]" /> 0% Financing Available
                </span>
                <span className="flex items-center gap-1.5 text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-[#FF5500]" /> 100% Assembled in Bavaria
                </span>
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col gap-3">
              <button
                type="button"
                onClick={onOpenOrderModal}
                className="w-full py-4 px-8 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider hover:scale-[1.02] shadow-[0_12px_32px_rgba(255,85,0,0.4)] active:scale-[0.98] transition-all text-center cursor-pointer"
              >
                Order RC 101 — €2,499
              </button>
              <button
                type="button"
                onClick={onNavigateToContact}
                className="w-full py-4 px-8 rounded-full border border-[#2A2E35] bg-[#16191F] text-[#F4F5F7] hover:border-[#FF5500] hover:text-[#FF5500] font-display text-xs font-bold uppercase tracking-wider transition-all text-center cursor-pointer"
              >
                Book Munich Test Ride
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
