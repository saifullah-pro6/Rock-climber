import React, { useState, useMemo } from 'react';
import { Product } from '../types';
import { PRODUCTS } from '../data/products';
import {
  Search,
  SlidersHorizontal,
  ShoppingBag,
  Plus,
  Check,
  ShieldCheck,
  Wrench,
  FileText,
  SearchX
} from 'lucide-react';

interface PartsShopPageProps {
  onAddToCart: (product: Product) => void;
  onOpenCart: () => void;
  cartCount: number;
  onNavigateToContact: () => void;
}

export const PartsShopPage: React.FC<PartsShopPageProps> = ({
  onAddToCart,
  onOpenCart,
  cartCount,
  onNavigateToContact
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<string>('popular');
  const [addedSku, setAddedSku] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'All Parts (8)' },
    { id: 'drivetrain', label: 'Drivetrain & Brakes' },
    { id: 'wheels', label: 'Wheels & Tires' },
    { id: 'cockpit', label: 'Cockpit & Grips' },
    { id: 'frame', label: 'Frame & Fork Upgrades' }
  ];

  const filteredProducts = useMemo(() => {
    let result = PRODUCTS.filter((p) => {
      const matchesCategory =
        selectedCategory === 'all' || p.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesQuery =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.spec.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });

    result.sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'weight') return a.weight - b.weight;
      return b.popularity - a.popularity;
    });

    return result;
  }, [selectedCategory, searchQuery, sortBy]);

  const handleAdd = (product: Product) => {
    onAddToCart(product);
    setAddedSku(product.sku);
    setTimeout(() => {
      setAddedSku(null);
    }, 1500);
  };

  const handleDownloadTorqueSpecs = () => {
    alert(
      "Rock Climber GmbH Technical Document:\n\n• Stem clamp bolts: 5.2 N·m\n• Rear axle Boost 148x12: 12.0 N·m\n• Shimano caliper mounting bolts: 7.0 N·m\n• Bottom bracket shell: 40.0 N·m\n• Seatpost collar: 4.5 N·m\n\nFull calibration manual generated."
    );
  };

  return (
    <div className="flex flex-col w-full">
      {/* Blueprint Technical Sub-Header */}
      <section className="relative w-full bg-[#0F1115] px-4 sm:px-6 lg:px-12 pt-10 pb-8 overflow-hidden border-b border-[#2A2E35]">
        <div className="absolute inset-0 cad-grid-dark opacity-15 pointer-events-none" />
        <div className="absolute -top-24 right-10 w-96 h-96 rounded-full bg-[#FF5500]/10 blur-[120px] pointer-events-none" />

        <div className="relative max-w-7xl mx-auto flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#16191F] border border-[#2A2E35]">
              <span className="w-2 h-2 rounded-full bg-[#FF5500] animate-ping" />
              <span className="font-tech text-[10px] text-[#FF5500] tracking-widest uppercase font-bold">
                Munich Factory Allocation // Parts Division
              </span>
            </div>
            <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl uppercase tracking-tight text-[#F4F5F7] font-extrabold">
              Official RC 101 Performance Parts &amp; Components
            </h1>
            <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
              Factory-inspected, precision-tolerance replacement equipment and race upgrades engineered specifically for the RC 101 Sports Edition chassis and high-load downhill trails.
            </p>
          </div>

          {/* Compatibility Badge */}
          <div className="p-4 rounded-xl bg-[#16191F] border border-[#2A2E35] shadow-xl flex items-center gap-4 flex-shrink-0">
            <div className="w-12 h-12 rounded-lg bg-[#0F1115] border border-[#2A2E35] flex items-center justify-center text-[#FF5500]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="font-tech text-[10px] uppercase tracking-wider text-[#FF5500] font-bold">
                Factory Guarantee
              </div>
              <div className="font-display text-sm font-bold text-white">
                100% RC 101 Compatibility
              </div>
              <div className="font-tech text-[10px] text-slate-400">
                DIN 79100 Tested // ISO 4210
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filter & Telemetry Controls Bar */}
      <section className="sticky top-20 z-30 w-full bg-[#16191F]/95 backdrop-blur-xl px-4 sm:px-6 lg:px-12 py-4 border-b border-[#2A2E35]">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0 scrollbar-none">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-full font-display text-xs uppercase tracking-wider font-bold whitespace-nowrap transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#FF5500] text-white shadow-[0_4px_16px_rgba(255,85,0,0.35)]'
                      : 'bg-[#0F1115] border border-[#2A2E35] text-slate-300 hover:text-white hover:border-slate-500'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* Search, Sort & Mini Cart Trigger */}
          <div className="flex items-center gap-3">
            {/* Search */}
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search spec, model, part #..."
                className="w-full pl-9 pr-4 py-2 rounded-full bg-[#0F1115] border border-[#2A2E35] text-white font-tech text-xs placeholder:text-slate-500 focus:outline-none focus:border-[#FF5500] transition-colors"
              />
            </div>

            {/* Sort Select */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none bg-[#0F1115] border border-[#2A2E35] text-white pl-4 pr-8 py-2 rounded-full font-tech text-xs uppercase focus:outline-none focus:border-[#FF5500] cursor-pointer"
              >
                <option value="popular">Popularity</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="weight">Ultralight First</option>
              </select>
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Tray Trigger */}
            <button
              onClick={onOpenCart}
              className="relative px-4 py-2 rounded-full bg-[#0F1115] border border-[#2A2E35] hover:border-[#FF5500] text-white font-display text-xs uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer flex-shrink-0"
            >
              <ShoppingBag className="w-4 h-4 text-[#FF5500]" />
              <span className="hidden sm:inline">Tray</span>
              <span className="w-5 h-5 rounded-full bg-[#FF5500] text-white text-[10px] font-bold flex items-center justify-center">
                {cartCount}
              </span>
            </button>
          </div>
        </div>
      </section>

      {/* Main Catalog Section */}
      <main className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-12">
        {/* Results Metadata Bar */}
        <div className="flex items-center justify-between mb-8 p-4 rounded-xl bg-[#16191F] border border-[#2A2E35]">
          <div className="flex items-center gap-3 font-tech text-xs text-slate-400">
            <span className="w-2 h-2 rounded-full bg-[#FF5500]" />
            <span>
              Showing {filteredProducts.length} Engineered Component
              {filteredProducts.length === 1 ? '' : 's'}
            </span>
            <span className="text-slate-600 hidden sm:inline">•</span>
            <span className="hidden sm:inline">Specs calibrated to ISO/DIN 4210 downhill standard</span>
          </div>
          <div className="hidden md:flex items-center gap-2 font-tech text-xs text-[#FF5500] uppercase font-bold">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#FF5500]" />
            Direct Dispatch: Ships within 24h
          </div>
        </div>

        {/* Product Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => {
              const isJustAdded = addedSku === product.sku;
              return (
                <article
                  key={product.id}
                  className="group relative flex flex-col justify-between rounded-2xl bg-[#16191F] border border-[#2A2E35] overflow-hidden hover:border-[#FF5500]/60 transition-all duration-300 shadow-lg"
                >
                  <div className="relative w-full h-56 bg-[#0C0E12] overflow-hidden">
                    <div className="absolute top-3 left-3 z-10">
                      <span className="font-tech text-[10px] uppercase px-2.5 py-1 rounded bg-[#FF5500] text-white font-bold tracking-wider">
                        {product.badge || 'OEM Spec'}
                      </span>
                    </div>
                    <div className="absolute top-3 right-3 z-10">
                      <span className="font-tech text-[10px] px-2 py-0.5 rounded bg-[#0F1115]/90 border border-[#2A2E35] text-slate-300 backdrop-blur-md">
                        {product.spec}
                      </span>
                    </div>
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between font-tech text-xs text-slate-400">
                        <span>SKU: {product.sku}</span>
                        <span>{product.weight.toLocaleString('de-DE')}g</span>
                      </div>
                      <h2 className="font-display text-sm font-bold text-white group-hover:text-[#FF5500] transition-colors line-clamp-2">
                        {product.name}
                      </h2>
                      <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                        {product.description}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-[#2A2E35] flex items-center justify-between">
                      <div>
                        <span className="font-tech text-[10px] text-slate-500 uppercase block">
                          Factory Price
                        </span>
                        <span className="font-display text-xl text-white font-bold">
                          €{product.price}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleAdd(product)}
                        className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-full font-display text-xs uppercase tracking-wider font-bold transition-all cursor-pointer ${
                          isJustAdded
                            ? 'bg-emerald-500 text-white'
                            : 'bg-[#FF5500] text-white hover:scale-105 shadow-[0_4px_16px_rgba(255,85,0,0.3)]'
                        }`}
                      >
                        {isJustAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Added</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-20 bg-[#16191F] border border-[#2A2E35] rounded-2xl p-8 space-y-4">
            <SearchX className="w-12 h-12 text-[#FF5500] mx-auto" />
            <h3 className="font-display text-lg uppercase text-white font-bold">
              No Engineering Components Matched
            </h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Adjust your search keywords or reset filter criteria to view our factory catalog inventory.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSortBy('popular');
              }}
              className="px-6 py-2.5 rounded-full bg-[#FF5500] text-white font-display text-xs uppercase tracking-wider font-bold hover:scale-105 transition-transform cursor-pointer"
            >
              Reset Catalog Filters
            </button>
          </div>
        )}

        {/* Technical Workshop & Assembly Banner */}
        <section className="mt-16 rounded-2xl bg-[#0F1115] border border-[#2A2E35] p-8 lg:p-12 relative overflow-hidden shadow-2xl">
          <div className="absolute right-0 bottom-0 w-1/3 h-full opacity-5 pointer-events-none flex items-center justify-end pr-8">
            <Wrench className="w-64 h-64 text-[#FF5500]" />
          </div>

          <div className="relative z-10 max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 font-tech text-xs uppercase tracking-widest text-[#FF5500] font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF5500]" />
              Factory Tech Support
            </div>
            <h2 className="font-display text-2xl sm:text-3xl text-white uppercase font-extrabold tracking-tight">
              Need Certified Workshop Installation?
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              All replacement components purchased through the official Rock Climber portal can be delivered directly to any of our 84 Bavarian certified service partners for zero-torque-error assembly.
            </p>
            <div className="pt-3 flex flex-wrap gap-4 items-center">
              <button
                type="button"
                onClick={onNavigateToContact}
                className="px-6 py-3 rounded-full bg-[#FF5500] text-white font-display text-xs uppercase tracking-wider font-bold shadow-[0_10px_28px_rgba(255,85,0,0.35)] hover:scale-[1.02] transition-all cursor-pointer"
              >
                Locate Nearest Service Center
              </button>
              <button
                type="button"
                onClick={handleDownloadTorqueSpecs}
                className="px-6 py-3 rounded-full border border-[#2A2E35] bg-[#16191F] text-slate-200 hover:text-[#FF5500] hover:border-[#FF5500] font-display text-xs uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>Download Torque Specs (PDF)</span>
              </button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
