import React, { useState } from 'react';
import { FrameSize } from '../types';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Send,
  Navigation,
  Compass,
  ArrowRight,
  HelpCircle
} from 'lucide-react';

interface ContactPageProps {
  onOpenOrderModal: () => void;
  selectedSize: FrameSize;
  onSelectSize: (size: FrameSize) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({
  selectedSize,
  onSelectSize
}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    riderHeight: '178 cm',
    selectedSize: selectedSize,
    preferredDate: '',
    preferredLocation: 'Munich HQ Test Track (Isar Gravel Loop)',
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 700);
  };

  const testLocations = [
    {
      id: 'munich-hq',
      name: 'Munich Engineering HQ & Isar Test Track',
      address: 'Leopoldstraße 142, 80804 Munich, Germany',
      surface: 'Gravel, Alpine single-track simulation & cobblestone',
      hours: 'Mon - Fri: 08:30 - 18:00 CET',
      badge: 'Main Factory'
    },
    {
      id: 'garmisch-hub',
      name: 'Garmisch-Partenkirchen Alpine Proving Ground',
      address: 'Kreuzeckbahnstraße 12, 82467 Garmisch, Germany',
      surface: 'Steep incline, loose shale, technical downhill ridge',
      hours: 'Thu - Sun: 09:00 - 17:00 CET',
      badge: 'Elevation Proving Ground'
    }
  ];

  const faqs = [
    {
      q: 'What is required for a test ride session?',
      a: 'Please bring a valid EU/National ID or passport and your preferred riding shoes. We provide sanitized German-certified helmets and pedals (Shimano SPD or standard alloy flats).'
    },
    {
      q: 'Can I test multiple frame sizes during one appointment?',
      a: 'Yes. Our factory technicians prepare adjacent sizes (e.g. M and L) alongside your pre-selected size so our laser fitment team can verify your optimal reach and stack.'
    },
    {
      q: 'Is there any fee or obligation to purchase after a test ride?',
      a: 'None whatsoever. The 45-minute German test ride experience is completely complimentary. We believe the RC 101 speaks for itself on the gravel.'
    },
    {
      q: 'Do you offer remote or virtual consults for international buyers?',
      a: 'Yes! We host 1-on-1 video consultations with our lead Munich bike technicians to dial in your exact body measurements before dispatch.'
    }
  ];

  return (
    <div className="min-h-screen bg-[var(--bg-main)] text-[var(--text-primary)] transition-colors duration-300">
      {/* Hero Header */}
      <section className="relative pt-32 pb-16 border-b border-[var(--border-color)] overflow-hidden">
        <div className="absolute inset-0 bg-radial-gradient pointer-events-none opacity-25" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-orange-500/30 bg-orange-500/10 text-orange-500 text-xs font-mono font-medium tracking-wider mb-4">
            <Compass className="w-3.5 h-3.5" />
            DIRECT BAVARIAN FACTORY CONTACT
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-black uppercase tracking-tight text-[var(--text-primary)] mb-4">
            Book a Test Ride <br />
            <span className="text-orange-500 font-extrabold">& Connect with Munich HQ</span>
          </h1>
          <p className="text-lg text-[var(--text-secondary)] max-w-2xl font-normal">
            Experience the unfiltered feedback of the RC 101 on our dedicated test track in Munich or reach our technical engineering team directly.
          </p>
        </div>
      </section>

      {/* Main Content Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            
            {/* Left Column: Test Ride Booking Form */}
            <div className="lg:col-span-7">
              <div className="bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-2xl p-6 sm:p-8 shadow-xl">
                <div className="flex items-center justify-between pb-6 mb-6 border-b border-[var(--border-color)]">
                  <div>
                    <h2 className="text-2xl font-black uppercase tracking-tight text-[var(--text-primary)]">
                      Test Ride Reservation
                    </h2>
                    <p className="text-xs text-[var(--text-secondary)] font-mono mt-1">
                      Direct factory track session with laser fitment protocol
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-500">
                    <Calendar className="w-5 h-5" />
                  </div>
                </div>

                {isSubmitted ? (
                  <div className="text-center py-12 px-4 space-y-4">
                    <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 mx-auto flex items-center justify-center animate-bounce">
                      <CheckCircle2 className="w-8 h-8" />
                    </div>
                    <h3 className="text-2xl font-bold uppercase tracking-tight text-[var(--text-primary)]">
                      Reservation Confirmed!
                    </h3>
                    <p className="text-sm text-[var(--text-secondary)] max-w-md mx-auto">
                      Vielen Dank, <strong className="text-[var(--text-primary)]">{formData.fullName}</strong>. Your test ride session has been logged in our Munich dispatch schedule. We sent confirmation and logistics instructions to <strong className="text-[var(--text-primary)]">{formData.email}</strong>.
                    </p>
                    <div className="p-4 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)] text-left max-w-md mx-auto text-xs font-mono space-y-2 mt-6">
                      <div className="flex justify-between">
                        <span className="text-[var(--text-secondary)]">Location:</span>
                        <span className="text-[var(--text-primary)] font-semibold truncate max-w-[200px]">{formData.preferredLocation}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[var(--text-secondary)]">Frame Size:</span>
                        <span className="text-orange-500 font-bold">{formData.selectedSize}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[var(--text-secondary)]">Date Requested:</span>
                        <span className="text-[var(--text-primary)] font-semibold">{formData.preferredDate || 'Next Available Slot'}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => setIsSubmitted(false)}
                      className="mt-6 px-6 py-2.5 rounded-xl border border-[var(--border-color)] hover:border-orange-500 text-xs font-mono font-semibold uppercase tracking-wider transition-colors"
                    >
                      Book Another Session
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-mono font-medium text-[var(--text-secondary)] uppercase tracking-wider mb-2">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          placeholder="e.g. Maximilian Weber"
                          className="w-full px-4 py-3 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)] text-[var(--text-primary)] placeholder-[var(--text-secondary)]/50 focus:outline-none focus:border-orange-500 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-mono font-medium text-[var(--text-secondary)] uppercase tracking-wider mb-2">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="m.weber@alpin-sports.de"
                          className="w-full px-4 py-3 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)] text-[var(--text-primary)] placeholder-[var(--text-secondary)]/50 focus:outline-none focus:border-orange-500 text-sm"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-mono font-medium text-[var(--text-secondary)] uppercase tracking-wider mb-2">
                          Mobile / Telephone
                        </label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="+49 170 1234567"
                          className="w-full px-4 py-3 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)] text-[var(--text-primary)] placeholder-[var(--text-secondary)]/50 focus:outline-none focus:border-orange-500 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-mono font-medium text-[var(--text-secondary)] uppercase tracking-wider mb-2">
                          Rider Height
                        </label>
                        <input
                          type="text"
                          value={formData.riderHeight}
                          onChange={(e) => setFormData({ ...formData, riderHeight: e.target.value })}
                          placeholder="e.g. 182 cm"
                          className="w-full px-4 py-3 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)] text-[var(--text-primary)] placeholder-[var(--text-secondary)]/50 focus:outline-none focus:border-orange-500 text-sm font-mono"
                        />
                      </div>
                    </div>

                    {/* Frame Size Choice */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs font-mono font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                          Target RC 101 Frame Size
                        </label>
                        <span className="text-xs font-mono text-orange-500">Selected: Size {formData.selectedSize}</span>
                      </div>
                      <div className="grid grid-cols-4 gap-3">
                        {(['S', 'M', 'L', 'XL'] as FrameSize[]).map((size) => (
                          <button
                            key={size}
                            type="button"
                            onClick={() => {
                              setFormData({ ...formData, selectedSize: size });
                              onSelectSize(size);
                            }}
                            className={`py-3 rounded-xl font-mono text-sm font-bold border transition-all ${
                              formData.selectedSize === size
                                ? 'bg-orange-500 text-white border-orange-500 shadow-lg shadow-orange-500/20'
                                : 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] border-[var(--border-color)] hover:border-orange-500/50'
                            }`}
                          >
                            Size {size}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Location Choice */}
                    <div>
                      <label className="block text-xs font-mono font-medium text-[var(--text-secondary)] uppercase tracking-wider mb-2">
                        Proving Ground Location
                      </label>
                      <select
                        value={formData.preferredLocation}
                        onChange={(e) => setFormData({ ...formData, preferredLocation: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)] text-[var(--text-primary)] focus:outline-none focus:border-orange-500 text-sm"
                      >
                        <option value="Munich HQ Test Track (Isar Gravel Loop)">
                          Munich HQ Test Track (Leopoldstraße 142)
                        </option>
                        <option value="Garmisch-Partenkirchen Alpine Ground">
                          Garmisch-Partenkirchen Proving Ground (Alpine Incline)
                        </option>
                        <option value="Virtual Video Fitment Session (Remote)">
                          Virtual Video Fitment Consultation (Global Remote)
                        </option>
                      </select>
                    </div>

                    {/* Preferred Date */}
                    <div>
                      <label className="block text-xs font-mono font-medium text-[var(--text-secondary)] uppercase tracking-wider mb-2">
                        Preferred Date
                      </label>
                      <input
                        type="date"
                        required
                        value={formData.preferredDate}
                        onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)] text-[var(--text-primary)] focus:outline-none focus:border-orange-500 text-sm font-mono"
                      />
                    </div>

                    {/* Special Notes */}
                    <div>
                      <label className="block text-xs font-mono font-medium text-[var(--text-secondary)] uppercase tracking-wider mb-2">
                        Notes or Suspension Preferences (Optional)
                      </label>
                      <textarea
                        rows={3}
                        value={formData.notes}
                        onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                        placeholder="Pedal preferences (SPD / flat), cockpit reach questions, or specific terrain tests..."
                        className="w-full px-4 py-3 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)] text-[var(--text-primary)] placeholder-[var(--text-secondary)]/50 focus:outline-none focus:border-orange-500 text-sm resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-mono font-bold uppercase tracking-wider text-sm shadow-xl shadow-orange-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          Confirm Test Ride Booking
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </div>

            {/* Right Column: HQ Contact & Emergency Hotline */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Bavarian HQ Direct Info */}
              <div className="bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-2xl p-6 sm:p-8">
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-orange-500/10 text-orange-500 font-mono text-xs font-semibold mb-4">
                  BAVARIA HEADQUARTERS
                </div>
                <h3 className="text-xl font-black uppercase tracking-tight text-[var(--text-primary)] mb-2">
                  Rock Climber GmbH
                </h3>
                <p className="text-xs text-[var(--text-secondary)] font-mono mb-6">
                  Handelsregister: Amtsgericht München HRB 265891
                </p>

                <div className="space-y-4">
                  <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)]">
                    <MapPin className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-primary)]">
                        Factory Address
                      </h4>
                      <p className="text-sm text-[var(--text-secondary)] mt-0.5">
                        Leopoldstraße 142<br />
                        80804 Munich, Bavaria, Germany
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)]">
                    <Mail className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-primary)]">
                        Direct Email Channels
                      </h4>
                      <p className="text-sm text-[var(--text-primary)] font-mono mt-0.5">
                        engineering@rockclimber.de
                      </p>
                      <p className="text-xs text-[var(--text-secondary)] font-mono">
                        service@rockclimber.de (Parts & Logistics)
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-color)]">
                    <Clock className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-primary)]">
                        Operating Hours
                      </h4>
                      <p className="text-sm text-[var(--text-secondary)] mt-0.5">
                        Monday – Friday: 08:00 – 18:00 CET<br />
                        Saturday: 09:00 – 14:00 CET (Proving Grounds only)
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Emergency Technical Hotline Card */}
              <div className="bg-gradient-to-br from-orange-500/10 via-[var(--bg-surface)] to-[var(--bg-surface)] border border-orange-500/30 rounded-2xl p-6 relative overflow-hidden">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-orange-500 text-white flex items-center justify-center shadow-lg shadow-orange-500/30">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-orange-500 font-bold">
                      Direct Dispatch Hotline
                    </span>
                    <h4 className="text-base font-black uppercase tracking-tight text-[var(--text-primary)]">
                      Munich Technical Support
                    </h4>
                  </div>
                </div>
                <p className="text-xs text-[var(--text-secondary)] mb-4">
                  For active RC 101 owners requiring immediate torque calibration specifications, replacement derailleur hangers, or emergency express logistics:
                </p>
                <div className="p-3 bg-[var(--bg-surface-elevated)] border border-orange-500/30 rounded-xl flex items-center justify-between">
                  <span className="text-base sm:text-lg font-mono font-black text-orange-500 tracking-wider">
                    +49 (0) 89 4520 8910
                  </span>
                  <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Live Dispatch
                  </span>
                </div>
              </div>

              {/* Location Previews */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[var(--text-secondary)]">
                  Proving Ground Hubs
                </h4>
                {testLocations.map((loc) => (
                  <div
                    key={loc.id}
                    className="p-4 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-color)] hover:border-orange-500/40 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <h5 className="text-sm font-bold text-[var(--text-primary)]">{loc.name}</h5>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-orange-500/10 text-orange-500 border border-orange-500/20">
                        {loc.badge}
                      </span>
                    </div>
                    <p className="text-xs text-[var(--text-secondary)] flex items-center gap-1 mb-2">
                      <Navigation className="w-3 h-3 text-orange-500 shrink-0" />
                      {loc.address}
                    </p>
                    <div className="text-[11px] font-mono text-[var(--text-secondary)] border-t border-[var(--border-color)] pt-2 mt-2">
                      <span className="text-orange-500 font-semibold">Terrain:</span> {loc.surface}
                    </div>
                  </div>
                ))}
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* FAQ Accordion Section */}
      <section className="py-16 border-t border-[var(--border-color)] bg-[var(--bg-surface)]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[var(--border-color)] bg-[var(--bg-surface-elevated)] text-[var(--text-secondary)] text-xs font-mono mb-3">
              <HelpCircle className="w-3.5 h-3.5 text-orange-500" />
              FREQUENTLY ASKED QUESTIONS
            </div>
            <h2 className="text-3xl font-black uppercase tracking-tight text-[var(--text-primary)]">
              Factory Test Ride Protocol
            </h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, index) => {
              const isOpen = activeFaq === index;
              return (
                <div
                  key={index}
                  className="rounded-xl border border-[var(--border-color)] bg-[var(--bg-surface-elevated)] overflow-hidden transition-all"
                >
                  <button
                    onClick={() => setActiveFaq(isOpen ? null : index)}
                    className="w-full p-5 text-left flex items-center justify-between text-sm sm:text-base font-bold text-[var(--text-primary)] hover:text-orange-500 transition-colors"
                  >
                    <span>{faq.q}</span>
                    <span className="text-orange-500 font-mono text-lg ml-4">
                      {isOpen ? '−' : '+'}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 text-xs sm:text-sm text-[var(--text-secondary)] leading-relaxed border-t border-[var(--border-color)]/60 pt-4">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};
