import React, { useState } from 'react';
import { FrameSize, CartItem } from '../types';
import { FLAGSHIP_BIKE } from '../data/products';
import { X, Check, ArrowRight, ShieldCheck, Truck, CreditCard, Landmark, CheckCircle2 } from 'lucide-react';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedSize: FrameSize;
  onSelectSize: (size: FrameSize) => void;
  cart: CartItem[];
  onOrderSuccess: () => void;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  selectedSize,
  onSelectSize,
  cart,
  onOrderSuccess
}) => {
  const [step, setStep] = useState<'config' | 'shipping' | 'confirmed'>('config');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    street: '',
    city: '',
    postalCode: '',
    country: 'Germany',
    paymentMethod: 'sepa',
    specialNotes: ''
  });
  const [orderSerial, setOrderSerial] = useState('');

  if (!isOpen) return null;

  // Determine items and total: if cart is empty, default to 1x RC 101 Sports Edition Flagship
  const hasCartItems = cart.length > 0;
  const items = hasCartItems
    ? cart
    : [{ product: FLAGSHIP_BIKE, quantity: 1, size: selectedSize }];
  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const randomSerial = `RC-101-DE-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    setOrderSerial(randomSerial);
    setStep('confirmed');
    onOrderSuccess();
  };

  const handleResetAndClose = () => {
    setStep('config');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl bg-[#16191F] border border-[#2A2E35] rounded-2xl shadow-2xl text-[#F4F5F7] overflow-hidden my-8 animate-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="p-6 bg-[#0F1115] border-b border-[#2A2E35] flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2 font-tech text-xs text-[#FF5500] uppercase tracking-wider font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF5500] animate-pulse" />
              Direct Munich Factory Allocation
            </div>
            <h3 className="font-display text-lg font-bold uppercase tracking-wide">
              {step === 'confirmed'
                ? 'Factory Allocation Confirmed'
                : 'Order RC 101 Sports Edition'}
            </h3>
          </div>
          <button
            onClick={handleResetAndClose}
            className="w-9 h-9 rounded-full bg-[#1E222B] hover:bg-[#2A2E35] text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step 1: Configuration & Sizing */}
        {step === 'config' && (
          <div className="p-6 sm:p-8 space-y-6">
            {/* Product Highlight Box */}
            <div className="flex flex-col sm:flex-row items-center gap-6 p-4 rounded-xl bg-[#0F1115] border border-[#2A2E35]">
              <img
                src={FLAGSHIP_BIKE.image}
                alt={FLAGSHIP_BIKE.name}
                className="w-full sm:w-44 h-28 object-contain rounded-lg bg-[#16191F] p-2"
              />
              <div className="space-y-1 flex-1 text-center sm:text-left">
                <span className="font-tech text-xs text-[#FF5500] uppercase font-bold">
                  Sports Edition Series 04
                </span>
                <h4 className="font-display text-base font-bold text-[#F4F5F7]">
                  RC 101 Flagship Hardtail
                </h4>
                <p className="text-xs text-slate-400">
                  Hydroformed 6061-T6 monocoque chassis, 29" knobby white-sidewall tires, Shimano 1x11 Shadow RD+, RST Blaze 100mm fork.
                </p>
                <div className="font-display font-extrabold text-[#FF5500] text-lg pt-1">
                  €2,499.00 <span className="text-xs font-tech text-slate-400 font-normal">Direct Factory Dispatch</span>
                </div>
              </div>
            </div>

            {/* Frame Size Selector */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-tech text-xs text-slate-300 uppercase tracking-wider font-semibold">
                  Select Frame Size & Rider Geometry
                </label>
                <span className="font-tech text-xs text-[#FF5500]">
                  DIN 79100 Verified Fit
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { size: 'S', inch: '15"', range: '155–168 cm', label: 'In Stock' },
                  { size: 'M', inch: '17"', range: '168–178 cm', label: 'Few Left' },
                  { size: 'L', inch: '19"', range: '178–188 cm', label: 'Popular' },
                  { size: 'XL', inch: '21"', range: '188+ cm', label: 'Ready' }
                ].map((item) => {
                  const isSelected = selectedSize === item.size;
                  return (
                    <button
                      key={item.size}
                      type="button"
                      onClick={() => onSelectSize(item.size as FrameSize)}
                      className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'border-[#FF5500] bg-[#FF5500]/10 shadow-[0_0_15px_rgba(255,85,0,0.2)]'
                          : 'border-[#2A2E35] bg-[#0F1115] hover:border-slate-500'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-display font-bold text-base text-[#F4F5F7]">
                          {item.size} <span className="text-xs text-slate-400 font-normal">({item.inch})</span>
                        </span>
                        {isSelected && <Check className="w-4 h-4 text-[#FF5500]" />}
                      </div>
                      <div className="font-tech text-[10px] text-slate-400 mt-1">{item.range}</div>
                      <div className="font-tech text-[9px] text-[#FF5500] uppercase font-bold mt-1">
                        {item.label}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Inclusions Guarantee Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-slate-300">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#FF5500]" />
                <span>Shock-Crated 98% Pre-Assembled</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#FF5500]" />
                <span>5-Year Monocoque Warranty</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#FF5500]" />
                <span>Torque Wrench & Cert Included</span>
              </div>
            </div>

            {/* Proceed to Shipping */}
            <div className="flex items-center justify-between pt-4 border-t border-[#2A2E35]">
              <div>
                <span className="text-xs text-slate-400 font-tech uppercase block">Total Net Price</span>
                <span className="font-display text-xl font-bold text-[#F4F5F7]">
                  €{subtotal.toLocaleString('de-DE')}.00
                </span>
              </div>
              <button
                type="button"
                onClick={() => setStep('shipping')}
                className="px-8 py-3.5 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider shadow-[0_10px_28px_rgba(255,85,0,0.35)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Continue to Shipping</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Shipping & Payment Address Form */}
        {step === 'shipping' && (
          <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
            <div className="space-y-4">
              <div className="font-tech text-xs text-slate-400 uppercase tracking-wider font-semibold border-b border-[#2A2E35] pb-2">
                01. Recipient Details & Freight Coordinates
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-tech text-[11px] text-slate-300 uppercase block mb-1">
                    Full Legal Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="e.g. Klaus Richter"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-[#F4F5F7] focus:outline-none focus:border-[#FF5500]"
                  />
                </div>
                <div>
                  <label className="font-tech text-[11px] text-slate-300 uppercase block mb-1">
                    Email Address (Dispatch Telemetry) *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="klaus@domain.de"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-[#F4F5F7] focus:outline-none focus:border-[#FF5500]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="font-tech text-[11px] text-slate-300 uppercase block mb-1">
                    Street Address & No. *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.street}
                    onChange={(e) => setFormData({ ...formData, street: e.target.value })}
                    placeholder="Alpenstraße 42"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-[#F4F5F7] focus:outline-none focus:border-[#FF5500]"
                  />
                </div>
                <div>
                  <label className="font-tech text-[11px] text-slate-300 uppercase block mb-1">
                    Phone (Freight Alert) *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+49 170 1234567"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-[#F4F5F7] focus:outline-none focus:border-[#FF5500]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="font-tech text-[11px] text-slate-300 uppercase block mb-1">
                    Postal Code *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.postalCode}
                    onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                    placeholder="80331"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-[#F4F5F7] focus:outline-none focus:border-[#FF5500]"
                  />
                </div>
                <div>
                  <label className="font-tech text-[11px] text-slate-300 uppercase block mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Munich"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-[#F4F5F7] focus:outline-none focus:border-[#FF5500]"
                  />
                </div>
                <div>
                  <label className="font-tech text-[11px] text-slate-300 uppercase block mb-1">
                    Country
                  </label>
                  <select
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-lg bg-[#0F1115] border border-[#2A2E35] text-xs font-tech text-[#F4F5F7] focus:outline-none focus:border-[#FF5500]"
                  >
                    <option value="Germany">Germany (Express 24h)</option>
                    <option value="Austria">Austria (DHL Alpine)</option>
                    <option value="Switzerland">Switzerland (Priority)</option>
                    <option value="European Union">European Union</option>
                    <option value="United States / Canada">North America (Air-Crated)</option>
                    <option value="United Kingdom">United Kingdom</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-3">
              <div className="font-tech text-xs text-slate-400 uppercase tracking-wider font-semibold border-b border-[#2A2E35] pb-2">
                02. Payment Architecture
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  {
                    id: 'sepa',
                    title: 'SEPA Direct / B2B',
                    desc: 'European bank clearing',
                    icon: Landmark
                  },
                  {
                    id: 'card',
                    title: 'Tokenized Card',
                    desc: 'PCI-DSS Level 1 256-bit',
                    icon: CreditCard
                  },
                  {
                    id: 'invoice',
                    title: 'Factory Proforma',
                    desc: 'Pay upon dispatch check',
                    icon: ShieldCheck
                  }
                ].map((method) => {
                  const Icon = method.icon;
                  const isSelected = formData.paymentMethod === method.id;
                  return (
                    <button
                      key={method.id}
                      type="button"
                      onClick={() => setFormData({ ...formData, paymentMethod: method.id })}
                      className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'border-[#FF5500] bg-[#FF5500]/10 text-white'
                          : 'border-[#2A2E35] bg-[#0F1115] text-slate-400 hover:border-slate-500'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-[#FF5500]' : 'text-slate-400'}`} />
                        <span className="font-display text-xs font-bold text-[#F4F5F7]">
                          {method.title}
                        </span>
                      </div>
                      <p className="text-[10px] font-tech text-slate-400">{method.desc}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Form Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-[#2A2E35]">
              <button
                type="button"
                onClick={() => setStep('config')}
                className="font-tech text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                ← Back to Configuration
              </button>
              <button
                type="submit"
                className="px-8 py-3.5 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider shadow-[0_10px_28px_rgba(255,85,0,0.35)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Authorize Allocation (€{subtotal.toLocaleString('de-DE')}.00)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}

        {/* Step 3: Confirmed Receipt Screen */}
        {step === 'confirmed' && (
          <div className="p-8 sm:p-10 space-y-6 text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-[0_0_24px_rgba(16,185,129,0.3)]">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>

            <div className="space-y-2">
              <span className="font-tech text-xs text-[#FF5500] uppercase font-bold tracking-widest">
                Factory Dispatch Serial Issued
              </span>
              <h4 className="font-display text-2xl font-bold uppercase text-[#F4F5F7]">
                Order Confirmed // {orderSerial}
              </h4>
              <p className="text-sm text-slate-400 max-w-md mx-auto">
                Thank you, <strong className="text-white">{formData.fullName || 'Valued Athlete'}</strong>. Your allocation is logged at the Rock Climber Technikum in Munich.
              </p>
            </div>

            {/* Receipt Summary Card */}
            <div className="p-5 rounded-xl bg-[#0F1115] border border-[#2A2E35] text-left space-y-3 font-tech text-xs">
              <div className="flex justify-between border-b border-[#2A2E35] pb-2 text-slate-400">
                <span>Model & Configuration</span>
                <span className="text-white font-semibold">
                  RC 101 Sports Edition (Size {selectedSize})
                </span>
              </div>
              <div className="flex justify-between border-b border-[#2A2E35] pb-2 text-slate-400">
                <span>Destination Coordinates</span>
                <span className="text-white font-semibold">
                  {formData.city || 'Munich'}, {formData.country}
                </span>
              </div>
              <div className="flex justify-between border-b border-[#2A2E35] pb-2 text-slate-400">
                <span>Assembly & Dispatch Status</span>
                <span className="text-[#FF5500] font-bold">
                  Bavaria Cleanroom Bay 04 // Ships within 24h
                </span>
              </div>
              <div className="flex justify-between items-baseline pt-1">
                <span className="text-slate-400">Amount Charged</span>
                <span className="font-display text-lg font-bold text-[#FF5500]">
                  €{subtotal.toLocaleString('de-DE')}.00
                </span>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                type="button"
                onClick={handleResetAndClose}
                className="w-full sm:w-auto px-8 py-3 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider hover:scale-105 transition-transform cursor-pointer"
              >
                Return to Experience
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="w-full sm:w-auto px-6 py-3 rounded-full border border-[#2A2E35] bg-[#1E222B] text-slate-300 hover:text-white font-tech text-xs tracking-wider uppercase transition-colors cursor-pointer"
              >
                Print Allocation Certificate
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
