import React, { useState } from 'react';
import { Page } from '../types';
import { Logo } from './Logo';
import { Mail, CheckCircle2, ArrowRight } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: Page) => void;
  onOpenOrderModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenOrderModal }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
    setTimeout(() => {
      setEmail('');
    }, 3000);
  };

  return (
    <footer className="w-full bg-[#16191F] dark:bg-[#16191F] border-t border-[#2A2E35] text-slate-400">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 pt-16 pb-12">
        {/* Newsletter Subscription Box */}
        <div className="p-8 mb-16 rounded-2xl bg-[#0F1115] border border-[#2A2E35] flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 shadow-xl relative overflow-hidden">
          <div className="absolute -right-16 -top-16 w-64 h-64 rounded-full bg-[#FF5500]/5 blur-3xl pointer-events-none" />
          
          <div className="max-w-md space-y-1">
            <div className="inline-flex items-center gap-2 font-tech text-xs text-[#FF5500] uppercase tracking-wider font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF5500] animate-pulse" />
              Munich Engineering Dispatch
            </div>
            <h3 className="font-display text-xl sm:text-2xl text-[#F4F5F7] uppercase tracking-tight font-bold">
              Precision Engineering Dispatch
            </h3>
            <p className="text-sm text-slate-400">
              Receive chassis telemetry updates, metallurgical whitepapers, and exclusive batch allocations.
            </p>
          </div>

          <div className="w-full lg:max-w-md">
            {subscribed ? (
              <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm font-medium">
                  Dispatch Confirmed. Technical whitepaper transmitted to {email || 'your email'}.
                </span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="engineer@domain.com"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0C0E12] border border-[#2A2E35] text-[#F4F5F7] font-tech text-xs placeholder:text-slate-600 focus:outline-none focus:border-[#FF5500] transition-colors"
                  />
                </div>
                <button
                  type="submit"
                  className="px-6 py-3 rounded-full bg-[#FF5500] text-[#F4F5F7] font-display text-xs font-bold uppercase tracking-wider hover:scale-[1.02] hover:shadow-[0_10px_28px_rgba(255,85,0,0.35)] active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap flex items-center justify-center gap-1.5"
                >
                  <span>Subscribe</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* 4-Column Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-16">
          {/* Column 1: Brand Overview */}
          <div className="space-y-4">
            <Logo showSubtitle={false} />
            <p className="text-sm text-slate-400 leading-relaxed">
              Est. 2020 Germany. Dedicated to surgical engineering, aerospace-grade titanium metallurgy, and race-proven downhill mountain machinery.
            </p>
            <div className="font-tech text-xs text-[#FF5500] tracking-widest uppercase font-semibold flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#FF5500]" />
              Munich • Bavaria • DE
            </div>
            <div className="pt-2 text-xs text-slate-500">
              ISO 9001 / DIN 79100 Tested Proving Grounds
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="font-display text-base text-[#F4F5F7] uppercase tracking-wider font-semibold mb-4">
              Quick Links
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-[#FF5500] transition-colors cursor-pointer text-left"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-[#FF5500] transition-colors cursor-pointer text-left"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('shop')}
                  className="hover:text-[#FF5500] transition-colors cursor-pointer text-left"
                >
                  Parts Shop
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#FF5500] transition-colors cursor-pointer text-left"
                >
                  Contact & Test Ride
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenOrderModal}
                  className="text-[#FF5500] hover:underline transition-colors cursor-pointer text-left font-semibold"
                >
                  Configure RC 101 →
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Flagship Tech */}
          <div>
            <h4 className="font-display text-base text-[#F4F5F7] uppercase tracking-wider font-semibold mb-4">
              Flagship Tech
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-[#FF5500] transition-colors cursor-pointer text-left font-medium text-[#F4F5F7]"
                >
                  RC 101 Sports Edition
                </button>
              </li>
              <li className="text-slate-400">Shimano 1x11 Shadow RD+ Drivetrain</li>
              <li className="text-slate-400">29" White-Sidewall Knobby Wheelset</li>
              <li className="text-slate-400">RST Blaze 100mm Lockout Suspension</li>
              <li className="text-slate-400">Hydroformed 6061-T6 Monocoque</li>
            </ul>
          </div>

          {/* Column 4: Network & Legal */}
          <div>
            <h4 className="font-display text-base text-[#F4F5F7] uppercase tracking-wider font-semibold mb-4">
              Network & Legal
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#FF5500] transition-colors cursor-pointer text-left"
                >
                  Dealer B2B Portal
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#FF5500] transition-colors cursor-pointer text-left"
                >
                  Book Proving Ground Test Ride
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('terms')}
                  className="hover:text-[#FF5500] transition-colors cursor-pointer text-left"
                >
                  Terms & Conditions
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('privacy')}
                  className="hover:text-[#FF5500] transition-colors cursor-pointer text-left"
                >
                  Privacy Policy (GDPR)
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar Copyright Notice */}
        <div className="pt-8 border-t border-[#2A2E35] flex flex-col sm:flex-row items-center justify-between gap-4 font-tech text-xs text-slate-500">
          <p>© 2026 Rock Climber GmbH. All Rights Reserved. Designed &amp; Developed by White Hats.</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Amtsgericht München HRB 284910</span>
            <span>·</span>
            <span className="text-[#FF5500]">DE 348 992 104</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
