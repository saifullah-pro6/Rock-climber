import React from 'react';

interface LogoProps {
  className?: string;
  showSubtitle?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = 'h-8', showSubtitle = true }) => {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Precision Engineered RC Triangle Emblem */}
      <div className="relative w-8 h-8 flex-shrink-0">
        <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-[0_2px_8px_rgba(255,85,0,0.4)]">
          {/* Background white/gray precision triangle */}
          <polygon
            points="24,6 36,34 12,34"
            stroke="currentColor"
            strokeWidth="3.2"
            strokeLinejoin="round"
            className="text-slate-400 dark:text-slate-300 opacity-60"
          />
          {/* Primary Summit Blaze Orange Apex Triangle */}
          <polygon
            points="14,6 26,34 2,34"
            stroke="#FF5500"
            strokeWidth="3.5"
            strokeLinejoin="round"
          />
          {/* Horizontal Precision Bridge Bar */}
          <line
            x1="4"
            y1="23"
            x2="28"
            y2="23"
            stroke="#FF5500"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          {/* Center alignment node */}
          <circle cx="14" cy="6" r="2.2" fill="#FF5500" />
        </svg>
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 leading-none">
          <span className="font-display font-extrabold tracking-wider text-slate-900 dark:text-[#F4F5F7] text-lg uppercase">
            Rock Climber
          </span>
          <span className="font-tech text-[10px] font-bold tracking-widest text-[#FF5500] px-1.5 py-0.5 rounded border border-[#FF5500]/40 bg-[#FF5500]/10">
            GMBH
          </span>
        </div>
        {showSubtitle && (
          <span className="font-tech text-[9px] tracking-[0.2em] text-slate-500 dark:text-slate-400 uppercase mt-0.5">
            German Precision Bicycles
          </span>
        )}
      </div>
    </div>
  );
};
