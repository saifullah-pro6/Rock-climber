import React from 'react';
import { FrameSize } from '../types';
import { X, Check } from 'lucide-react';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedSize: FrameSize;
  onSelectSize: (size: FrameSize) => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({
  isOpen,
  onClose,
  selectedSize,
  onSelectSize
}) => {
  if (!isOpen) return null;

  const sizeRows = [
    {
      size: 'S' as FrameSize,
      inch: '15"',
      heightCm: '155 – 168 cm',
      heightFt: '5\'1" – 5\'6"',
      inseam: '71 – 77 cm',
      reach: '415 mm',
      stack: '608 mm',
      standover: '745 mm',
      note: 'Optimal for agile technical jumps and compact pilots.'
    },
    {
      size: 'M' as FrameSize,
      inch: '17"',
      heightCm: '168 – 178 cm',
      heightFt: '5\'6" – 5\'10"',
      inseam: '76 – 82 cm',
      reach: '445 mm',
      stack: '618 mm',
      standover: '775 mm',
      note: 'Ideal all-round downhill and trail balance.'
    },
    {
      size: 'L' as FrameSize,
      inch: '19"',
      heightCm: '178 – 188 cm',
      heightFt: '5\'10" – 6\'2"',
      inseam: '81 – 88 cm',
      reach: '475 mm',
      stack: '628 mm',
      standover: '805 mm',
      note: 'Factory race-tested baseline geometry for aggressive stability.'
    },
    {
      size: 'XL' as FrameSize,
      inch: '21"',
      heightCm: '188 – 205 cm',
      heightFt: '6\'2" – 6\'8"',
      inseam: '86 – 94 cm',
      reach: '505 mm',
      stack: '642 mm',
      standover: '835 mm',
      note: 'Extended wheelbase for high-speed alpine descents and tall riders.'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-3xl bg-[#16191F] border border-[#2A2E35] rounded-2xl shadow-2xl text-[#F4F5F7] overflow-hidden my-8 animate-in zoom-in-95 duration-200">
        <div className="p-6 bg-[#0F1115] border-b border-[#2A2E35] flex items-center justify-between">
          <div>
            <span className="font-tech text-xs text-[#FF5500] uppercase font-bold tracking-widest">
              DIN 79100 Biomechanical Standards
            </span>
            <h3 className="font-display text-lg font-bold uppercase text-[#F4F5F7] mt-0.5">
              RC 101 Rider Geometry & Sizing Guide
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#1E222B] hover:bg-[#2A2E35] text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <p className="text-sm text-slate-400 leading-relaxed">
            Our Munich proving grounds test crew calibrates each RC 101 frame to millimeter tolerances. Select your size below to highlight your recommended build.
          </p>

          <div className="overflow-x-auto rounded-xl border border-[#2A2E35] bg-[#0F1115]">
            <table className="w-full text-left font-tech text-xs">
              <thead className="bg-[#1E222B] text-slate-400 uppercase border-b border-[#2A2E35]">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Size</th>
                  <th className="py-3.5 px-4">Rider Height</th>
                  <th className="py-3.5 px-4">Inseam</th>
                  <th className="py-3.5 px-4">Reach</th>
                  <th className="py-3.5 px-4">Stack</th>
                  <th className="py-3.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2A2E35]/60">
                {sizeRows.map((row) => {
                  const isSelected = selectedSize === row.size;
                  return (
                    <tr
                      key={row.size}
                      className={`transition-colors ${
                        isSelected ? 'bg-[#FF5500]/10 font-bold' : 'hover:bg-[#1E222B]/50'
                      }`}
                    >
                      <td className="py-3.5 px-4">
                        <span className="font-display text-base text-white">{row.size}</span>{' '}
                        <span className="text-slate-400 font-normal">({row.inch})</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-200">
                        {row.heightCm} <span className="text-slate-400">({row.heightFt})</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">{row.inseam}</td>
                      <td className="py-3.5 px-4 text-slate-300">{row.reach}</td>
                      <td className="py-3.5 px-4 text-slate-300">{row.stack}</td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => {
                            onSelectSize(row.size);
                            onClose();
                          }}
                          className={`px-3 py-1 rounded-full text-[11px] font-bold uppercase transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#FF5500] text-white flex items-center gap-1 ml-auto'
                              : 'border border-[#2A2E35] bg-[#1E222B] text-slate-300 hover:border-[#FF5500] hover:text-[#FF5500]'
                          }`}
                        >
                          {isSelected ? (
                            <>
                              <Check className="w-3 h-3" /> Selected
                            </>
                          ) : (
                            'Select'
                          )}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="p-4 rounded-xl bg-[#0F1115] border border-[#2A2E35] text-xs text-slate-400 space-y-1">
            <span className="font-tech text-white font-bold block uppercase">
              Factory Stem & Bar Tuning:
            </span>
            <p>
              All RC 101 purchases include complimentary cockpit consultation. On arrival, factory mechanics can configure stem length (40mm / 50mm) and handlebar width (760mm / 780mm) to match your exact arm reach.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
