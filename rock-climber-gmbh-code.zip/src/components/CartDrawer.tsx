import React from 'react';
import { CartItem } from '../types';
import { ShoppingBag, X, Trash2, Plus, Minus, ArrowRight, ShieldCheck } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (sku: string, qty: number) => void;
  onRemoveItem: (sku: string) => void;
  onProceedToCheckout: () => void;
  onNavigateToShop: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  onNavigateToShop
}) => {
  if (!isOpen) return null;

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#16191F] border-l border-[#2A2E35] flex flex-col justify-between shadow-2xl text-[#F4F5F7] animate-in slide-in-from-right duration-300">
          {/* Header */}
          <div className="p-6 bg-[#0F1115] border-b border-[#2A2E35] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#FF5500]/15 flex items-center justify-center text-[#FF5500]">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-display text-base font-bold uppercase tracking-wider text-[#F4F5F7]">
                  Allocation Tray
                </h3>
                <span className="font-tech text-xs text-slate-400">
                  Direct Factory Dispatch // Munich
                </span>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-[#1E222B] hover:bg-[#2A2E35] text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              aria-label="Close Allocation Tray"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-20 space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-[#1E222B] flex items-center justify-center text-slate-500">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="font-display text-base font-semibold text-[#F4F5F7]">
                    Allocation Tray Is Empty
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                    Select engineered components from the catalog or configure your RC 101 chassis.
                  </p>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onNavigateToShop();
                  }}
                  className="px-5 py-2.5 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider hover:scale-105 transition-transform cursor-pointer"
                >
                  Browse Parts Catalog
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={`${item.product.sku}-${item.size || 'default'}`}
                  className="flex gap-4 p-4 rounded-xl bg-[#1E222B] border border-[#2A2E35] transition-all hover:border-slate-600"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-20 h-20 rounded-lg object-cover bg-[#0F1115] border border-[#2A2E35] flex-shrink-0"
                  />
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h5 className="font-display text-xs font-bold text-[#F4F5F7] line-clamp-1">
                          {item.product.name}
                        </h5>
                        <button
                          onClick={() => onRemoveItem(item.product.sku)}
                          className="text-slate-500 hover:text-[#FF5500] transition-colors p-1"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="font-tech text-[10px] text-slate-400 mt-0.5">
                        SKU: {item.product.sku}
                        {item.size && <span className="ml-2 text-[#FF5500]">SIZE: {item.size}</span>}
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-3 pt-2 border-t border-[#2A2E35]">
                      <div className="flex items-center gap-2 bg-[#0F1115] px-2 py-1 rounded-lg border border-[#2A2E35]">
                        <button
                          onClick={() => onUpdateQuantity(item.product.sku, item.quantity - 1)}
                          className="w-5 h-5 flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-tech text-xs font-bold px-1.5">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(item.product.sku, item.quantity + 1)}
                          className="w-5 h-5 flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="text-right">
                        <span className="font-display font-bold text-sm text-[#F4F5F7]">
                          €{(item.product.price * item.quantity).toLocaleString('de-DE')}.00
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Checkout Summary */}
          {cart.length > 0 && (
            <div className="p-6 bg-[#0F1115] border-t border-[#2A2E35] space-y-4">
              <div className="space-y-2 font-tech text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal ({totalItems} items)</span>
                  <span className="text-[#F4F5F7] font-semibold">
                    €{subtotal.toLocaleString('de-DE')}.00
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Express Freight (DHL Bavaria)</span>
                  <span className="text-[#FF5500] uppercase font-bold tracking-wider">
                    Complimentary
                  </span>
                </div>
                <div className="pt-2 border-t border-[#2A2E35] flex justify-between items-baseline text-base font-display">
                  <span className="text-[#F4F5F7] font-bold">Estimated Total (Incl. VAT)</span>
                  <span className="text-[#FF5500] font-black text-xl">
                    €{subtotal.toLocaleString('de-DE')}.00
                  </span>
                </div>
              </div>

              <button
                onClick={onProceedToCheckout}
                className="w-full py-4 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider shadow-[0_10px_28px_rgba(255,85,0,0.35)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Secure Allocation Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-center pt-1 text-[11px] font-tech text-slate-400">
                <ShieldCheck className="w-4 h-4 text-[#FF5500]" />
                <span>German Engineering Guarantee • 30-Day Return</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
