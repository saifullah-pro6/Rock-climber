import React, { useState } from 'react';
import { Page, Theme } from '../types';
import { Logo } from './Logo';
import { Sun, Moon, ShoppingBag, Menu, X, ArrowRight } from 'lucide-react';

interface HeaderProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  theme: Theme;
  onToggleTheme: () => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenOrderModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  theme,
  onToggleTheme,
  cartCount,
  onOpenCart,
  onOpenOrderModal
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { label: string; page: Page }[] = [
    { label: 'Home', page: 'home' },
    { label: 'About Us', page: 'about' },
    { label: 'Parts Shop', page: 'shop' },
    { label: 'Contact & Test Ride', page: 'contact' },
  ];

  const handleNavClick = (page: Page) => {
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 transition-colors duration-300 backdrop-blur-xl bg-[#0F1115]/85 dark:bg-[#0F1115]/85 light:bg-white/90 border-b border-[#2A2E35] dark:border-[#2A2E35] light:border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 h-20 flex items-center justify-between">
        {/* Brand Zone */}
        <button
          onClick={() => handleNavClick('home')}
          className="cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#FF5500] rounded-lg transition-transform hover:scale-[1.01]"
          aria-label="Rock Climber GmbH Home"
        >
          <Logo />
        </button>

        {/* Desktop Nav Zone */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => {
            const isActive = currentPage === item.page;
            return (
              <button
                key={item.page}
                onClick={() => handleNavClick(item.page)}
                className={`text-sm font-medium tracking-wide transition-all relative py-1 focus:outline-none focus-visible:ring-1 focus-visible:ring-[#FF5500] cursor-pointer ${
                  isActive
                    ? 'text-[#FF5500] dark:text-[#FF5500] font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-[#F4F5F7]'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#FF5500] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Action Controls Zone */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Dark / Light Mode Switcher */}
          <button
            onClick={onToggleTheme}
            aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
            className="w-10 h-10 rounded-full flex items-center justify-center border border-[#2A2E35] dark:border-[#2A2E35] light:border-slate-300 bg-[#16191F] dark:bg-[#16191F] light:bg-slate-100 text-slate-700 dark:text-slate-200 hover:border-[#FF5500] hover:text-[#FF5500] dark:hover:text-[#FF5500] transition-all duration-300 cursor-pointer"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400 transition-transform duration-300 rotate-0 hover:rotate-90" />
            ) : (
              <Moon className="w-4 h-4 text-slate-700 transition-transform duration-300 rotate-0 hover:-rotate-12" />
            )}
          </button>

          {/* Cart Drawer Trigger */}
          <button
            onClick={onOpenCart}
            aria-label="Open Component Allocation Tray"
            className="relative w-10 h-10 rounded-full flex items-center justify-center border border-[#2A2E35] dark:border-[#2A2E35] light:border-slate-300 bg-[#16191F] dark:bg-[#16191F] light:bg-slate-100 text-slate-700 dark:text-slate-200 hover:border-[#FF5500] hover:text-[#FF5500] transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#FF5500] text-white font-tech text-[10px] font-bold flex items-center justify-center shadow-[0_0_8px_rgba(255,85,0,0.6)] animate-in zoom-in-50">
                {cartCount}
              </span>
            )}
          </button>

          {/* Primary Action Button: "Order RC 101" */}
          <button
            onClick={onOpenOrderModal}
            className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider shadow-[0_10px_28px_rgba(255,85,0,0.35)] hover:scale-[1.02] hover:shadow-[0_12px_32px_rgba(255,85,0,0.5)] active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap"
          >
            <span>Order RC 101</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden w-10 h-10 rounded-lg flex items-center justify-center border border-[#2A2E35] text-slate-400 hover:text-[#F4F5F7] transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0F1115] border-b border-[#2A2E35] px-6 py-6 space-y-4 animate-in slide-in-from-top-4 duration-200">
          <nav className="flex flex-col space-y-3">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => handleNavClick(item.page)}
                className={`text-left py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                  currentPage === item.page
                    ? 'bg-[#FF5500]/15 text-[#FF5500] font-semibold'
                    : 'text-slate-300 hover:bg-[#16191F] hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
          <div className="pt-3 border-t border-[#2A2E35] flex flex-col gap-3">
            <button
              onClick={() => {
                onOpenOrderModal();
                setMobileMenuOpen(false);
              }}
              className="w-full py-3 rounded-full bg-[#FF5500] text-white font-display text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg"
            >
              <span>Order RC 101 (€2,499)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
              <span>Munich Proving Ground // DE</span>
              <span className="text-[#FF5500] font-tech">EST. 2020</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
